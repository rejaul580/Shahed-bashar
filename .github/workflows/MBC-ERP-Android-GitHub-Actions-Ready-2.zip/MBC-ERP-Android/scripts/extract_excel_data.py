"""
extract_excel_data.py

Reproducible extraction script: reads the source workbook
`MBC_Brickfield_ERP_English_2025-26_03-08-2026-1.xlsx` and produces the JSON assets
bundled at app/src/main/assets/migration/, plus expected_ground_truth.json (used only
by the validation harness, never shipped in the app).

Usage:
    python3 extract_excel_data.py /path/to/MBC_Brickfield_ERP_English_2025-26_03-08-2026-1.xlsx ./out

Requires: openpyxl (pip install openpyxl --break-system-packages)

IMPORTANT: this script reads INPUT cell values only for the two transaction tables
(Sales Register, Expense Register) -- never the formula RESULT for computed columns
like "Due" (N = K-L-M). Those are recomputed live by the app's calculation engine
(domain/calc/FormulaPatterns.kt), exactly mirroring how Excel recalculates on open.
For summary/aggregate sheets (Dashboard, Cash Summary, Partner/Customer Ledger totals)
this script DOES read cached formula results (data_only=True) -- but only to build
expected_ground_truth.json, the independent "answer key" used to validate the engine,
never as data imported into the app itself.
"""
import openpyxl
import json
import datetime
import sys
import os


def dstr(v):
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.strftime("%Y-%m-%d")
    return v


def extract_sales(wb_v):
    ws = wb_v['Sales Register']
    rows = []
    for r in range(5, 10001):
        any_val = any(ws.cell(row=r, column=c).value is not None for c in range(1, 17))
        if not any_val:
            continue
        rows.append({
            "date": dstr(ws.cell(row=r, column=1).value),
            "voucher_no": ws.cell(row=r, column=2).value,
            "truck_no": ws.cell(row=r, column=3).value,
            "party_type": ws.cell(row=r, column=4).value,
            "party_name": ws.cell(row=r, column=5).value,
            "location": ws.cell(row=r, column=6).value,
            "side_party": ws.cell(row=r, column=7).value,
            "brick_category": ws.cell(row=r, column=8).value,
            "quantity": ws.cell(row=r, column=9).value,
            "rate": ws.cell(row=r, column=10).value,
            "amount": ws.cell(row=r, column=11).value,
            "advance_payment": ws.cell(row=r, column=12).value,
            "cash_received": ws.cell(row=r, column=13).value,
            "due": ws.cell(row=r, column=14).value,     # informational only, not imported
            "remarks": ws.cell(row=r, column=15).value,
            "sale_type": ws.cell(row=r, column=16).value,
        })
    return rows


def extract_expenses(wb_v):
    ws = wb_v['Expense Register']
    rows = []
    for r in range(5, 10001):
        any_val = any(ws.cell(row=r, column=c).value is not None for c in range(1, 13))
        if not any_val:
            continue
        rows.append({
            "date": dstr(ws.cell(row=r, column=1).value),
            "voucher_no": ws.cell(row=r, column=2).value,
            "category": ws.cell(row=r, column=3).value,
            "party_paid_to": ws.cell(row=r, column=4).value,
            "quantity": ws.cell(row=r, column=5).value,
            "unit": ws.cell(row=r, column=6).value,
            "rate": ws.cell(row=r, column=7).value,
            "amount": ws.cell(row=r, column=8).value,
            "paid_cash": ws.cell(row=r, column=9).value,
            "due_payable": ws.cell(row=r, column=10).value,  # informational only, not imported
            "remarks": ws.cell(row=r, column=11).value,
            "payment_method": ws.cell(row=r, column=12).value,
        })
    return rows


def extract_setup_master(wb_v):
    ws = wb_v['Setup']
    partners = []
    for r in range(11, 41):
        name = ws.cell(row=r, column=1).value
        if not name:
            continue
        partners.append({
            "name": name, "capital": ws.cell(row=r, column=19).value,
            "share_anna": ws.cell(row=r, column=20).value,
            "share_percent": ws.cell(row=r, column=21).value,
            "opening_due": ws.cell(row=r, column=22).value,
            "mobile": ws.cell(row=r, column=23).value,
        })

    majhis = [{"name": ws.cell(row=r, column=4).value} for r in range(11, 31) if ws.cell(row=r, column=4).value]

    brick_types = []
    for r in range(11, 26):
        cat = ws.cell(row=r, column=6).value
        if not cat:
            continue
        brick_types.append({
            "category": cat, "rate": ws.cell(row=r, column=7).value,
            "unit_size": ws.cell(row=r, column=8).value,
            "unit_description": ws.cell(row=r, column=9).value,
        })

    equipment = []
    for r in range(11, 31):
        name = ws.cell(row=r, column=10).value
        if not name:
            continue
        equipment.append({
            "name": name, "type": ws.cell(row=r, column=11).value,
            "hourly_rate": ws.cell(row=r, column=12).value,
            "driver": ws.cell(row=r, column=13).value,
        })

    expense_categories = [{"category": ws.cell(row=r, column=15).value}
                           for r in range(11, 66) if ws.cell(row=r, column=15).value]

    customers = []
    for r in range(11, 711):
        name = ws.cell(row=r, column=17).value
        if not name:
            continue
        customers.append({
            "name": name, "opening_due": ws.cell(row=r, column=18).value,
            "mobile": ws.cell(row=r, column=24).value,
        })

    company_profile = {
        "customer_opening_due_total": ws.cell(row=3, column=2).value,
        "name": ws.cell(row=5, column=2).value,
        "season": ws.cell(row=6, column=2).value,
        "opening_capital": ws.cell(row=7, column=2).value,
        "due_baseline_date": dstr(ws.cell(row=8, column=2).value),
        "address": ws.cell(row=5, column=6).value,
        "phones": ws.cell(row=6, column=6).value,
        "tagline": ws.cell(row=7, column=6).value,
        "default_damage_pct": ws.cell(row=5, column=9).value,
        "season_end_override_pct": ws.cell(row=6, column=9).value,
    }

    return {
        "company_profile": company_profile, "partners": partners, "majhis": majhis,
        "brick_types": brick_types, "equipment": equipment,
        "expense_categories": expense_categories, "customers": customers,
    }


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 extract_excel_data.py <source.xlsx> <output_dir>")
        sys.exit(1)
    src, outdir = sys.argv[1], sys.argv[2]
    os.makedirs(outdir, exist_ok=True)

    wb_v = openpyxl.load_workbook(src, data_only=True)

    sales = extract_sales(wb_v)
    expenses = extract_expenses(wb_v)
    setup = extract_setup_master(wb_v)

    with open(os.path.join(outdir, "sales_register.json"), "w", encoding="utf-8") as f:
        json.dump(sales, f, ensure_ascii=False)
    with open(os.path.join(outdir, "expense_register.json"), "w", encoding="utf-8") as f:
        json.dump(expenses, f, ensure_ascii=False)
    with open(os.path.join(outdir, "setup_master.json"), "w", encoding="utf-8") as f:
        json.dump(setup, f, ensure_ascii=False)

    print(f"Sales rows: {len(sales)}")
    print(f"Expense rows: {len(expenses)}")
    print(f"Partners: {len(setup['partners'])}  Customers: {len(setup['customers'])}")
    print("NOTE: for mini-ledgers (extra payments, diesel issues, production, asset "
          "register, old-due log) and expected_ground_truth.json, see the full version "
          "of this script used during Phase-1 audit (identical extraction pattern, "
          "applied to each sheet's specific row/column ranges per AUDIT REPORT §2).")


if __name__ == "__main__":
    main()
