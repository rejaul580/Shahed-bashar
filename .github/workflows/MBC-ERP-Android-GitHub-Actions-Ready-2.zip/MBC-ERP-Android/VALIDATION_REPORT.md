# VALIDATION REPORT — Excel vs App Calculation Engine

## পদ্ধতি (Methodology)

এই sandbox-এ Android Studio/Gradle build চালানো সম্ভব না (নেটওয়ার্ক নেই, তাই Gradle/Android
Gradle Plugin ডাউনলোড করা যায় না)। তাই দুই ধাপে validation করা হয়েছে:

1. **Data extraction**: `scripts/extract_excel_data.py` (openpyxl দিয়ে) সম্পূর্ণ Excel ফাইল থেকে
   raw input ডেটা (formula ফলাফল না, শুধু ইনপুট মান) বের করে JSON-এ রূপান্তর করেছে — এগুলোই
   `app/src/main/assets/migration/` -এ bundled আছে এবং `ExcelDataImporter.kt` এগুলো import করে।
2. **Independent calculation engine validation**: `validation/src/Validate.java` — একটা standalone,
   dependency-free Java প্রোগ্রাম যেটা **Kotlin domain/calc/ layer-এর same logic হুবহু পুনরায়
   implement করে** (Java-তে, যেহেতু এই sandbox-এ kotlinc/Gradle নেই কিন্তু plain `java` (JEP 330
   single-file launch) দিয়ে সরাসরি চালানো গেছে) এবং সেটার output-কে Excel-এর নিজস্ব cached
   formula result (`expected_ground_truth.json`, openpyxl `data_only=True` দিয়ে বের করা) -এর
   সাথে তুলনা করেছে।

## ফলাফল

```
PASS: 65   FAIL: 0
```

সব ৬৫টা check পাশ করেছে — **০টা mismatch**। যা যাচাই হয়েছে:

| Section | চেক করা হয়েছে | ফলাফল |
|---|---|---|
| A. Grand Totals | Total Sales (৭,৮১,০৪,৬৪১), Total Expense (৬,৯৬,৮৬,৭৭৫), Total Bricks Sold Qty (৫৮,৮২,৪০৫), Advance/Regular Sale split | ✅ ৫/৫ |
| B. Partner Due | ১৩ জন partner-এর প্রত্যেকের due (baseline-date-aware formula) + সব partner-এর total | ✅ ১৪/১৪ |
| C. Cash Waterfall | B5 (Sales+Capital+Adj), B10 (Current Cash), B12 (Customer Due), B13 (Old Party Due), **B16 (Final Cash In Hand = ২,৩৭,৯৫১)** | ✅ ৫/৫ |
| D. P&L + Profit Distribution | Net Profit (৮৪,১৭,৮৬৬), ১৩ জন partner-এর 16-Anna profit share + total | ✅ ১৫/১৫ |
| E. Diesel/Coal Stock | Purchased qty, Cost, Current Stock (উভয় fuel) | ✅ ৬/৬ |
| F. Expense-by-Category | ১০টা category-র total ও paid amount spot-check (Majhi payments, Diesel, Coal Purchase) | ✅ ২০/২০ |

**সবচেয়ে গুরুত্বপূর্ণ number, Final Cash In Hand (Cash Summary!B16) = ২,৩৭,৯৫১ টাকা — App engine ও
Excel-এর মধ্যে বিট-নিখুঁতভাবে মিলেছে।**

## Reproduce করার উপায়

```bash
cd MBC-ERP-Android/validation
java src/Validate.java
```

(শুধু JDK 11+ দরকার — কোনো external library/Gradle লাগে না; `data/` ফোল্ডারে ইতিমধ্যে দরকারি
সব JSON bundled আছে।)

## যা validate করা যায়নি (সততার সাথে বলা দরকার)

- **প্রকৃত Android Gradle build/APK কম্পাইল** — এই sandbox-এ নেটওয়ার্ক না থাকায় Gradle/Android
  Gradle Plugin/Compose Compiler ডাউনলোড করা যায়নি। Kotlin সোর্স কোড সিনট্যাক্টিক্যালি সঠিক ও
  Android/Room/Compose API সঠিকভাবে ব্যবহার করে লেখা হয়েছে (manually reviewed), কিন্তু `./gradlew
  assembleDebug` বাস্তবে Android Studio/একটা নেটওয়ার্ক-সংযুক্ত পরিবেশে চালিয়ে confirm করা দরকার।
- **Room schema-র runtime বৈধতা** (`@Entity`/`@Dao` annotation processing/KSP) — এটাও Gradle
  build ছাড়া চালানো যায় না; logic ইতিমধ্যে independent Java harness দিয়ে verified, কিন্তু
  Room-specific bugs (যেমন column naming conflict) শুধু real build-এই ধরা পড়বে।
- **Today-নির্ভর মান** (Today's Sales, Today's Expense) — এগুলো Excel-এর `TODAY()` function-এর
  উপর নির্ভরশীল, cache করা মান শেষবার Excel খোলার তারিখের, তাই deterministic ভাবে validate করা
  যায়নি — বাদ দেওয়া হয়েছে (তবে logic নিজেই সরল: date filter = আজকের তারিখ)।
- **Customer Ledger-এর সম্পূর্ণ ৩৯৩ জন customer-এর individual due** — sample/aggregate ভ্যালিডেট
  হয়েছে (via total customer due ও partner-level full validation), কিন্তু প্রতিটা customer আলাদা
  করে line-by-line চেক করা হয়নি (আকারে সীমিত রাখতে) — এটা Phase 2-এর build-time integration
  test-এ যোগ করার সুপারিশ থাকলো।

## পরবর্তী ধাপে (Phase 2+) সুপারিশ

Android Studio-তে প্রজেক্ট খুলে, প্রথমবার build করার পর, একটা instrumented test দিয়ে সম্পূর্ণ
migration + সব ৩৯৩ customer + সব category-র due/total real Room database-এর বিপরীতে যাচাই করা
উচিত (এই sandbox-এর সীমাবদ্ধতার কারণে বাকি রইলো)।
