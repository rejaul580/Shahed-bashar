package com.mbcerp.domain.entry

import org.junit.Assert.assertEquals
import org.junit.Test

class EntryGuideEngineTest {

    private fun baseInput(mode: EntryMode, cash: Double = 0.0, amount: Double = 0.0) = SalesEntryInput(
        mode = mode, date = "2026-08-19", voucherNo = "V-1", truckNo = "T-1",
        partyType = "Partner", partyName = "Karim", brickCategory = "1 No",
        quantity = 1000.0, rate = 9.5, amount = amount, cashAmount = cash
    )

    @Test
    fun `Regular Sale keeps cash sign as entered and tags Regular Sale`() {
        val input = baseInput(EntryMode.RegularSale, cash = 5000.0, amount = 10000.0)
        val rows = EntryGuideEngine.buildSaleEntities(input)
        assertEquals(1, rows.size)
        assertEquals(5000.0, rows[0].cashReceived, 0.001)
        assertEquals("Regular Sale", rows[0].saleType)
        assertEquals(10000.0, rows[0].amount, 0.001)
    }

    @Test
    fun `Partner Due Settlement forces positive cash and blank sale type`() {
        // Even if the user types a negative number by mistake, the mode forces the correct sign.
        val input = baseInput(EntryMode.PartnerDueSettlement, cash = -3000.0)
        val rows = EntryGuideEngine.buildSaleEntities(input)
        assertEquals(1, rows.size)
        assertEquals(3000.0, rows[0].cashReceived, 0.001)
        assertEquals(null, rows[0].saleType)
        assertEquals(0.0, rows[0].amount, 0.001) // brick fields stay blank per Entry Guide rule #2
    }

    @Test
    fun `Advance To Partner forces negative cash - money leaving the field`() {
        val input = baseInput(EntryMode.AdvanceToPartner, cash = 2000.0) // user types positive
        val rows = EntryGuideEngine.buildSaleEntities(input)
        assertEquals(-2000.0, rows[0].cashReceived, 0.001) // engine flips sign per rule #3
        assertEquals(null, rows[0].saleType)
    }

    @Test
    fun `Advance Sale forces positive cash and Advance Sale tag`() {
        val input = baseInput(EntryMode.AdvanceSale, cash = 15000.0)
        val rows = EntryGuideEngine.buildSaleEntities(input)
        assertEquals(15000.0, rows[0].cashReceived, 0.001)
        assertEquals("Advance Sale", rows[0].saleType)
    }

    @Test
    fun `Due Transfer Between Partners produces exactly 2 rows with opposite signs and equal amount`() {
        val input = baseInput(EntryMode.DueTransferBetweenPartners, cash = 4000.0)
        val rows = EntryGuideEngine.buildSaleEntities(input, counterpartyName = "Jamal")
        assertEquals(2, rows.size)
        assertEquals("Karim", rows[0].partyName)
        assertEquals(-4000.0, rows[0].cashReceived, 0.001)
        assertEquals("Jamal", rows[1].partyName)
        assertEquals(4000.0, rows[1].cashReceived, 0.001)
        // Net cash effect across both rows must be zero -- no real money moved.
        assertEquals(0.0, rows[0].cashReceived + rows[1].cashReceived, 0.001)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `Due Transfer without a counterparty name throws`() {
        val input = baseInput(EntryMode.DueTransferBetweenPartners, cash = 1000.0)
        EntryGuideEngine.buildSaleEntities(input) // no counterpartyName passed
    }
}
