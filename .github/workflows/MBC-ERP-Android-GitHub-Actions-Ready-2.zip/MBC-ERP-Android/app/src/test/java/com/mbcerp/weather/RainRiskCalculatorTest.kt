package com.mbcerp.weather

import org.junit.Assert.*
import org.junit.Test

class RainRiskCalculatorTest {

    private fun point(h: Int, prob: Int, mm: Double) = RainRiskCalculator.HourlyForecastPoint(h, prob, mm)

    @Test
    fun `no risk when all probabilities are below threshold`() {
        val forecast = listOf(point(1, 10, 0.0), point(5, 20, 0.5), point(10, 30, 0.2))
        val result = RainRiskCalculator.assess(forecast)
        assertEquals(RainRiskCalculator.RiskLevel.NONE, result.level)
        assertNull(result.firstRiskyHourFromNow)
    }

    @Test
    fun `low risk just above probability threshold`() {
        val forecast = listOf(point(3, 45, 1.0))
        val result = RainRiskCalculator.assess(forecast)
        assertEquals(RainRiskCalculator.RiskLevel.LOW, result.level)
        assertEquals(3, result.firstRiskyHourFromNow)
        assertFalse(RainRiskCalculator.shouldNotify(result.level))
    }

    @Test
    fun `moderate risk at 60 percent`() {
        val forecast = listOf(point(4, 65, 2.0))
        val result = RainRiskCalculator.assess(forecast)
        assertEquals(RainRiskCalculator.RiskLevel.MODERATE, result.level)
        assertTrue(RainRiskCalculator.shouldNotify(result.level))
    }

    @Test
    fun `high risk at 80 percent`() {
        val forecast = listOf(point(2, 85, 3.0))
        val result = RainRiskCalculator.assess(forecast)
        assertEquals(RainRiskCalculator.RiskLevel.HIGH, result.level)
    }

    @Test
    fun `severe risk when heavy rain mm threshold crossed regardless of probability`() {
        val forecast = listOf(point(6, 45, 9.0)) // only 45% prob, but 9mm >= 7.5mm heavy threshold
        val result = RainRiskCalculator.assess(forecast)
        assertEquals(RainRiskCalculator.RiskLevel.SEVERE, result.level)
    }

    @Test
    fun `only considers hours within the lead-time window`() {
        val thresholds = RainRiskCalculator.Thresholds(leadTimeHours = 6)
        val forecast = listOf(point(20, 95, 10.0)) // way outside the 6-hour window
        val result = RainRiskCalculator.assess(forecast, thresholds)
        assertEquals(RainRiskCalculator.RiskLevel.NONE, result.level)
    }

    @Test
    fun `picks the earliest risky hour, not the worst one`() {
        val forecast = listOf(point(8, 90, 8.0), point(2, 45, 0.5))
        val result = RainRiskCalculator.assess(forecast)
        assertEquals(2, result.firstRiskyHourFromNow) // earliest risky hour, even though hour 8 is worse
    }

    @Test
    fun `empty forecast returns NONE with explanatory reason`() {
        val result = RainRiskCalculator.assess(emptyList())
        assertEquals(RainRiskCalculator.RiskLevel.NONE, result.level)
        assertTrue(result.reason.isNotBlank())
    }

    @Test
    fun `custom thresholds change classification boundaries`() {
        val strict = RainRiskCalculator.Thresholds(probabilityThresholdPercent = 10, heavyRainMm = 2.0)
        val forecast = listOf(point(1, 15, 3.0)) // 15% prob (above strict 10%), 3mm (above strict heavy 2mm)
        val result = RainRiskCalculator.assess(forecast, strict)
        assertEquals(RainRiskCalculator.RiskLevel.SEVERE, result.level) // heavy-mm escalation still applies
    }
}
