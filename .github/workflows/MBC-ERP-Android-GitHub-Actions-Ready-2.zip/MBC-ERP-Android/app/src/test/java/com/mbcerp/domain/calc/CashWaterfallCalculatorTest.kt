package com.mbcerp.domain.calc

import com.mbcerp.data.entity.CashSummaryAdjustmentEntity
import com.mbcerp.data.entity.ExpenseEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class CashWaterfallCalculatorTest {

    @Test
    fun `compute reproduces the Cash Summary waterfall on a known fixture`() {
        // Fixture mirrors the real workbook's magnitudes (scaled down) so the chain of
        // subtractions can be hand-verified: see AUDIT REPORT §4.3 for the source formula.
        val adjustments = CashSummaryAdjustmentEntity(
            season = "test", seasonFixedAdjustment = 500.0, advanceExpenseNextYear = 100.0,
            coalRelatedDeposit = 50.0, priorYearDueReturn = 20.0, oldDueStartingPool = 1000.0,
            forwardDue = 0.0, otherAdjustments = 30.0
        )
        val result = CashWaterfallCalculator.compute(
            totalSales = 10000.0, openingCapital = 2000.0, totalExpense = 6000.0,
            totalPartnerDue = 800.0, totalCustomerDue = 400.0, oldDueTotalCollected = 300.0,
            adjustments = adjustments
        )
        // B5 = 10000 + 2000 + 500 = 12500
        assertEquals(12500.0, result.totalSalesAndCapital, 0.001)
        // B10 = 12500 - 6000 - 100 - 50 + 20 = 6370
        assertEquals(6370.0, result.currentCashBeforeDue, 0.001)
        // B13 = 1000 - 300 = 700
        assertEquals(700.0, result.oldPartyDue2024_25, 0.001)
        // B16 = 6370 - 800 - 400 - 700 - 0 - 30 = 4440
        assertEquals(4440.0, result.finalCashInHand, 0.001)
    }

    @Test
    fun `netProfitLoss is simply totalSales minus totalExpense`() {
        assertEquals(2500.0, CashWaterfallCalculator.netProfitLoss(10000.0, 7500.0), 0.001)
    }
}

class ProfitDistributionCalculatorTest {
    @Test
    fun `distribute splits net profit by anna share out of 16`() {
        val shares = ProfitDistributionCalculator.distribute(
            netProfit = 1_600_000.0,
            partners = listOf("A" to 8.0, "B" to 4.0, "C" to 4.0)
        )
        assertEquals(800_000.0, shares[0].profitShare, 0.001) // 8/16
        assertEquals(400_000.0, shares[1].profitShare, 0.001) // 4/16
        assertEquals(400_000.0, shares[2].profitShare, 0.001) // 4/16
        assertEquals(1_600_000.0, shares.sumOf { it.profitShare }, 0.001)
    }
}

class StockCalculatorTest {
    private fun expense(category: String, quantity: Double, amount: Double) =
        ExpenseEntity(date = "2026-08-01", category = category, quantity = quantity, amount = amount)

    @Test
    fun `dieselStock equals purchased minus issued`() {
        val expenses = listOf(
            expense("Diesel", quantity = 500.0, amount = 50000.0),
            expense("Diesel Transport", quantity = 0.0, amount = 2000.0)
        )
        val result = StockCalculator.dieselStock(expenses, dieselIssuedTotal = 120.0)
        assertEquals(500.0, result.purchasedOrProduced, 0.001)
        assertEquals(52000.0, result.totalCost, 0.001)
        assertEquals(380.0, result.currentStock, 0.001)
    }

    @Test
    fun `productionStockEstimate applies damage percent then subtracts sold quantity`() {
        // 10000 loaded, 5% damage -> 9500 produced, minus 4000 sold = 5500 stock
        val stock = StockCalculator.productionStockEstimate(
            totalLoadedToKiln = 10000.0, damagePercent = 0.05, totalSoldOfCoveredCategories = 4000.0
        )
        assertEquals(5500.0, stock, 0.001)
    }
}

class ValidationEngineTest {
    @Test
    fun `checkPartnerShareTotal passes only when annas sum to exactly 16`() {
        assertEquals(true, ValidationEngine.checkPartnerShareTotal(16.0).ok)
        assertEquals(false, ValidationEngine.checkPartnerShareTotal(15.5).ok)
    }

    @Test
    fun `checkNoDuplicateNames detects duplicates`() {
        val result = ValidationEngine.checkNoDuplicateNames(listOf("A", "B", "A"), "partner")
        assertEquals(false, result.ok)
    }
}
