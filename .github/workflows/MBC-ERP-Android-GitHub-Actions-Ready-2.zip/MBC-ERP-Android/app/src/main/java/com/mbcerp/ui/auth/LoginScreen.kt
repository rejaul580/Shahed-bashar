package com.mbcerp.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.auth.AuthManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * LOGIN / FIRST-RUN PIN SETUP (completes Phase 1 item 4 with an actual UI, AuthManager
 * itself already existed). First launch: create an OWNER PIN. After that: PIN prompt
 * every app start (Decision D4/D8: local-only, no server verification).
 */
class LoginViewModel(private val authManager: AuthManager) : ViewModel() {
    private val _isFirstRun = MutableStateFlow<Boolean?>(null)
    val isFirstRun: StateFlow<Boolean?> = _isFirstRun
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _success = MutableStateFlow(false)
    val success: StateFlow<Boolean> = _success

    fun checkFirstRun() = viewModelScope.launch { _isFirstRun.value = authManager.isFirstRun() }

    fun createOwner(username: String, pin: String, confirmPin: String) = viewModelScope.launch {
        if (pin.length < 4) { _error.value = "PIN কমপক্ষে ৪ সংখ্যার হতে হবে"; return@launch }
        if (pin != confirmPin) { _error.value = "PIN দুটো মিলছে না"; return@launch }
        authManager.createOwnerAccount(username, pin)
        _success.value = true
    }

    fun login(username: String, pin: String) = viewModelScope.launch {
        val ok = authManager.login(username, pin)
        if (ok) _success.value = true else _error.value = "ভুল Username বা PIN"
    }
}

class LoginViewModelFactory(private val authManager: AuthManager) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = LoginViewModel(authManager) as T
}

@Composable
fun LoginScreen(vm: LoginViewModel, onLoggedIn: () -> Unit) {
    val isFirstRun by vm.isFirstRun.collectAsState()
    val error by vm.error.collectAsState()
    val success by vm.success.collectAsState()

    LaunchedEffect(Unit) { vm.checkFirstRun() }
    LaunchedEffect(success) { if (success) onLoggedIn() }

    var username by remember { mutableStateOf("owner") }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.background)
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        when (isFirstRun) {
            null -> CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            true -> LoginCard {
                Icon(Icons.Default.LockOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(10.dp))
                Text("প্রথমবার লঞ্চ", style = MaterialTheme.typography.titleMedium)
                Text("আপনার Owner PIN সেট করুন", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(username, { username = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(pin, { pin = it }, label = { Text("PIN (৪+ সংখ্যা)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(confirmPin, { confirmPin = it }, label = { Text("PIN আবার লিখুন") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Spacer(Modifier.height(18.dp))
                Button(onClick = { vm.createOwner(username, pin, confirmPin) }, modifier = Modifier.fillMaxWidth()) { Text("PIN সেট করুন") }
            }
            false -> LoginCard {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(10.dp))
                Text("MBC ইটভাটা ERP", style = MaterialTheme.typography.titleMedium)
                Text("লগইন করুন", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(username, { username = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(pin, { pin = it }, label = { Text("PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Spacer(Modifier.height(18.dp))
                Button(onClick = { vm.login(username, pin) }, modifier = Modifier.fillMaxWidth()) { Text("লগইন") }
            }
        }
    }
}

@Composable
private fun LoginCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp)
    ) {
        Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}
