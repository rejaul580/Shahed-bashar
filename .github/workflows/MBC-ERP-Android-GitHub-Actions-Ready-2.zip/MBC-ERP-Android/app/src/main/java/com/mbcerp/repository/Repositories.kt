package com.mbcerp.repository

import com.mbcerp.data.dao.*
import com.mbcerp.data.entity.*
import com.mbcerp.domain.calc.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

/**
 * Repository layer sits between ViewModels and Room DAOs / the calculation engine.
 * Decision D4: written as an interface-free simple class for Phase 1 (single local data
 * source); a future remote-sync data source can be slotted in behind these same method
 * signatures without any ViewModel/UI changes.
 */
class SetupRepository(
    private val companyProfileDao: CompanyProfileDao,
    private val partnerDao: PartnerDao,
    private val majhiDao: MajhiDao,
    private val brickTypeDao: BrickTypeDao,
    private val equipmentDao: EquipmentDao,
    private val expenseCategoryDao: ExpenseCategoryDao,
    private val customerDao: CustomerDao
) {
    fun observeCompanyProfile(): Flow<CompanyProfileEntity?> = companyProfileDao.observe()
    suspend fun saveCompanyProfile(profile: CompanyProfileEntity) = companyProfileDao.upsert(profile)

    /** Setup screen "Baseline Date" field (Phase 1 item 5). */
    suspend fun updateBaselineDate(newDate: LocalDate) {
        val current = companyProfileDao.get() ?: return
        companyProfileDao.upsert(current.copy(dueBaselineDate = newDate.toString()))
    }

    fun observePartners(): Flow<List<PartnerEntity>> = partnerDao.observeAll()
    suspend fun addPartner(p: PartnerEntity) = partnerDao.insert(p)
    suspend fun updatePartner(p: PartnerEntity) = partnerDao.update(p)
    suspend fun removePartner(id: Long) = partnerDao.softDelete(id)

    fun observeMajhis(): Flow<List<MajhiEntity>> = majhiDao.observeAll()
    suspend fun addMajhi(m: MajhiEntity) = majhiDao.insert(m)

    fun observeBrickTypes(): Flow<List<BrickTypeEntity>> = brickTypeDao.observeAll()
    suspend fun addBrickType(b: BrickTypeEntity) = brickTypeDao.insert(b)
    suspend fun rateFor(category: String): Double = brickTypeDao.rateFor(category) ?: 0.0

    fun observeEquipment(): Flow<List<EquipmentEntity>> = equipmentDao.observeAll()
    suspend fun addEquipment(e: EquipmentEntity) = equipmentDao.insert(e)

    fun observeExpenseCategories(): Flow<List<ExpenseCategoryEntity>> = expenseCategoryDao.observeAll()
    suspend fun addExpenseCategory(c: ExpenseCategoryEntity) = expenseCategoryDao.insert(c)

    fun observeCustomers(): Flow<List<CustomerEntity>> = customerDao.observeAll()
    suspend fun addCustomer(c: CustomerEntity) = customerDao.insert(c)
    suspend fun updateCustomer(c: CustomerEntity) = customerDao.update(c)

    /** Setup Audit check (mirrors Audit Sheet!B6): partner Anna shares must total 16. */
    suspend fun auditPartnerShareTotal(): ValidationEngine.AuditResult =
        ValidationEngine.checkPartnerShareTotal(partnerDao.totalShareAnna() ?: 0.0)
}

class SalesRepository(private val saleDao: SaleDao, private val brickTypeDao: BrickTypeDao) {
    fun observeAll(): Flow<List<SaleEntity>> = saleDao.observeAll()
    suspend fun getForDate(date: LocalDate) = saleDao.getForDate(date.toString())
    suspend fun getForParty(partyType: String, partyName: String) = saleDao.getForParty(partyType, partyName)
    suspend fun totalAmount() = saleDao.totalAmount()

    /** Sales entry: auto rate-lookup (Pattern 1) applied before insert, exactly like Sales Register!J. */
    suspend fun addSale(sale: SaleEntity): Long {
        val rate = if (sale.rate <= 0.0) brickTypeDao.rateFor(sale.brickCategory) ?: 0.0 else sale.rate
        return saleDao.insert(sale.copy(rate = rate, updatedAt = System.currentTimeMillis()))
    }

    suspend fun updateSale(sale: SaleEntity) = saleDao.update(sale.copy(updatedAt = System.currentTimeMillis()))
    suspend fun removeSale(id: Long) = saleDao.softDelete(id)
    suspend fun findByVoucher(voucherNo: String) = saleDao.findByVoucher(voucherNo)
}

class ExpenseRepository(private val expenseDao: ExpenseDao) {
    fun observeAll(): Flow<List<ExpenseEntity>> = expenseDao.observeAll()
    suspend fun getForDate(date: LocalDate) = expenseDao.getForDate(date.toString())
    suspend fun getForCategory(category: String) = expenseDao.getForCategory(category)
    suspend fun getForParty(name: String) = expenseDao.getForParty(name)
    suspend fun totalAmount() = expenseDao.totalAmount()
    suspend fun totalsByCategory() = expenseDao.totalsByCategory()

    suspend fun addExpense(expense: ExpenseEntity): Long =
        expenseDao.insert(expense.copy(updatedAt = System.currentTimeMillis()))

    suspend fun updateExpense(expense: ExpenseEntity) =
        expenseDao.update(expense.copy(updatedAt = System.currentTimeMillis()))

    suspend fun removeExpense(id: Long) = expenseDao.softDelete(id)
}

/** Customer/Partner Ledger due engine wired to real DAOs (Phase 1 item 10). */
class LedgerRepository(
    private val saleDao: SaleDao,
    private val extraPaymentDao: ExtraPaymentDao,
    private val customerDao: CustomerDao,
    private val partnerDao: PartnerDao,
    private val companyProfileDao: CompanyProfileDao
) {
    private suspend fun baselineDate(): LocalDate =
        LocalDate.parse(companyProfileDao.get()?.dueBaselineDate ?: "2026-07-14")

    suspend fun customerDue(customerName: String): DueCalculator.CustomerDueSummary {
        val customer = customerDao.findByName(customerName)
        val sales = saleDao.getForParty("Customer", customerName)
        val extra = extraPaymentDao.customerTotal(customerName)
        return DueCalculator.customerDue(sales, customerName, customer?.openingDue ?: 0.0, extra)
    }

    suspend fun partnerDue(partnerName: String): DueCalculator.PartnerDueSummary {
        val partners = partnerDao.getAll()
        val partner = partners.firstOrNull { it.name == partnerName }
        val sales = saleDao.getForParty("Partner", partnerName)
        val extra = extraPaymentDao.partnerTotal(partnerName)
        return DueCalculator.partnerDue(sales, partnerName, partner?.openingDue ?: 0.0, baselineDate(), extra)
    }

    suspend fun allPartnerDues(): List<DueCalculator.PartnerDueSummary> =
        partnerDao.getAll().map { partnerDue(it.name) }

    suspend fun totalPartnerDue(): Double = allPartnerDues().sumOf { it.totalDue }
}

/** Cash Summary screen wiring (Phase 1 item 11). */
class CashSummaryRepository(
    private val saleDao: SaleDao,
    private val expenseDao: ExpenseDao,
    private val companyProfileDao: CompanyProfileDao,
    private val adjustmentDao: CashSummaryAdjustmentDao,
    private val oldDueDao: OldDueCollectionDao,
    private val ledgerRepository: LedgerRepository,
    private val customerDao: CustomerDao,
    private val extraPaymentDao: ExtraPaymentDao
) {
    suspend fun compute(): CashWaterfallCalculator.WaterfallResult {
        val profile = companyProfileDao.get()!!
        val season = profile.season
        val adjustments = adjustmentDao.get(season) ?: CashSummaryAdjustmentEntity(season = season)

        val totalSales = saleDao.totalAmount()
        val totalExpense = expenseDao.totalAmount()
        val totalPartnerDue = ledgerRepository.totalPartnerDue()

        val baseline = LocalDate.parse(profile.dueBaselineDate)
        var custSum = 0.0; var custAdv = 0.0; var custCash = 0.0
        // Aggregate customer due across ALL customers directly (company-wide total, matches Cash Summary!B12).
        val allSales = saleDao.getAll()
        for (row in allSales) {
            if (row.partyType != "Customer") continue
            val d = runCatching { LocalDate.parse(row.date) }.getOrNull() ?: continue
            if (!d.isAfter(baseline)) continue
            custSum += row.amount; custAdv += row.advancePayment; custCash += row.cashReceived
        }
        val totalCustomerDue = profile.customerOpeningDueTotal + custSum - custAdv - custCash

        val oldDueCollected = oldDueDao.totalCollected()

        return CashWaterfallCalculator.compute(
            totalSales = totalSales,
            openingCapital = profile.openingCapital,
            totalExpense = totalExpense,
            totalPartnerDue = totalPartnerDue,
            totalCustomerDue = totalCustomerDue,
            oldDueTotalCollected = oldDueCollected,
            adjustments = adjustments
        )
    }

    suspend fun saveAdjustments(adjustments: CashSummaryAdjustmentEntity) = adjustmentDao.upsert(adjustments)
    fun observeAdjustments(season: String) = adjustmentDao.observe(season)
    suspend fun getAdjustments(season: String): CashSummaryAdjustmentEntity =
        adjustmentDao.get(season) ?: CashSummaryAdjustmentEntity(season = season)

    /** Season P&L (Cash Summary rows 20-24): simple totalSales - totalExpense, deliberately
     *  excludes opening capital and the seasonFixedAdjustment (those only affect the cash
     *  waterfall, not the P&L figure) -- mirrors the source sheet's B23 formula exactly. */
    suspend fun netProfit(): Double = saleDao.totalAmount() - expenseDao.totalAmount()
}

/** Diesel/Coal/Majhi/Equipment register wiring (AUDIT §2.5, §2.6 — Phase 4). */
class RegisterRepository(
    private val expenseDao: ExpenseDao,
    private val stockDao: StockDao,
    private val majhiDao: MajhiDao,
    private val equipmentDao: EquipmentDao
) {
    suspend fun dieselStock(): StockCalculator.StockResult =
        StockCalculator.dieselStock(expenseDao.getAll(), stockDao.totalDieselIssued())

    suspend fun coalStock(): StockCalculator.StockResult =
        StockCalculator.coalStock(expenseDao.getAll(), stockDao.totalCoalUsed())

    suspend fun dieselPurchaseRows() = expenseDao.getForCategory("Diesel") + expenseDao.getForCategory("Diesel Transport")
    suspend fun coalPurchaseRows() = expenseDao.getForCategory("Coal Purchase") +
        expenseDao.getForCategory("Coal Transport") + expenseDao.getForCategory("Coal Breaking")

    fun observeMajhis() = majhiDao.observeAll()
    suspend fun majhiLedgerRows(majhiName: String) = expenseDao.getForParty(majhiName)
    suspend fun majhiTotalAdvance(majhiName: String) = expenseDao.getForParty(majhiName).sumOf { it.amount }

    fun observeEquipment() = equipmentDao.observeAll()
    suspend fun equipmentLedgerRows(equipmentName: String) = expenseDao.getForParty(equipmentName)
    suspend fun equipmentTotalHours(equipmentName: String) = stockDao.totalHoursFor(equipmentName)
    suspend fun equipmentTotalPaid(equipmentName: String) = expenseDao.getForParty(equipmentName).sumOf { it.paidCash }

    /** Ledger Viewer + Expense Summary: generic any-category filtered view (replaces all 41 HL_ sheets). */
    suspend fun categoryRows(category: String) = expenseDao.getForCategory(category)
    suspend fun categoryTotals() = expenseDao.totalsByCategory()
}

/** Dashboard + Daily Report KPI wiring (AUDIT §2.8 — Phase 7). */
class DashboardRepository(
    private val saleDao: SaleDao,
    private val expenseDao: ExpenseDao,
    private val companyProfileDao: CompanyProfileDao,
    private val ledgerRepository: LedgerRepository,
    private val cashSummaryRepository: CashSummaryRepository,
    private val registerRepository: RegisterRepository
) {
    data class DashboardKpis(
        val totalCapital: Double,
        val cashInHand: Double,
        val totalSalesAmount: Double,
        val totalExpenseAmount: Double,
        val totalBricksSoldQty: Double,
        val totalCustomerDue: Double,
        val totalPartnerDue: Double,
        val totalPayableExpenseDue: Double,
        val dieselStockLiter: Double,
        val coalStock: Double,
        val totalAdvanceSale: Double,
        val totalRegularSale: Double
    )

    suspend fun kpis(): DashboardKpis {
        val profile = companyProfileDao.get()
        val totalSales = saleDao.totalAmount()
        val totalExpense = expenseDao.totalAmount()
        val waterfall = cashSummaryRepository.compute()
        val partnerDue = ledgerRepository.totalPartnerDue()
        val diesel = registerRepository.dieselStock()
        val coal = registerRepository.coalStock()
        val expenseTotals = expenseDao.totalsByCategory()
        val totalPayableExpenseDue = expenseTotals.sumOf { it.total - it.paid }
        var advanceSale = 0.0
        for (s in saleDao.getAll()) if (s.saleType == "Advance Sale") advanceSale += s.amount
        return DashboardKpis(
            totalCapital = profile?.openingCapital ?: 0.0,
            cashInHand = waterfall.finalCashInHand,
            totalSalesAmount = totalSales,
            totalExpenseAmount = totalExpense,
            totalBricksSoldQty = saleDao.totalQuantity(),
            totalCustomerDue = waterfall.customerDue,
            totalPartnerDue = partnerDue,
            totalPayableExpenseDue = totalPayableExpenseDue,
            dieselStockLiter = diesel.currentStock,
            coalStock = coal.currentStock,
            totalAdvanceSale = advanceSale,
            totalRegularSale = totalSales - advanceSale
        )
    }

    suspend fun dailySales(date: String) = saleDao.getForDate(date)
    suspend fun dailyExpenses(date: String) = expenseDao.getForDate(date)
}

/** Production Register wiring (AUDIT §2.9 — Phase 8). Decision D6: only "1 No"/"2 No" counted. */
class ProductionRepository(
    private val productionDao: ProductionDao,
    private val saleDao: SaleDao,
    private val companyProfileDao: CompanyProfileDao
) {
    fun observeAll() = productionDao.observeAll()
    suspend fun addEntry(e: ProductionEntryEntity) = productionDao.insert(e)

    suspend fun stockEstimate(): Double {
        val totalLoaded = productionDao.totalLoadedToKiln()
        val damagePct = companyProfileDao.get()?.defaultDamagePercent ?: 0.05
        val soldCovered = saleDao.getAll()
            .filter { it.brickCategory == "1 No" || it.brickCategory == "2 No" }
            .sumOf { it.quantity }
        return StockCalculator.productionStockEstimate(totalLoaded, damagePct, soldCovered)
    }
}

/** Asset Register wiring (AUDIT §2.10 — Phase 8, manual-entry only, no auto-sync). */
class AssetRegisterRepository(private val assetRegisterDao: AssetRegisterDao) {
    fun observeAll() = assetRegisterDao.observeAll()
    suspend fun addEntry(e: AssetRegisterEntity) = assetRegisterDao.insert(e)
}

/** Audit/Validation screen wiring (AUDIT §2.11 — Phase 9). */
class AuditRepository(
    private val partnerDao: PartnerDao,
    private val majhiDao: MajhiDao,
    private val equipmentDao: EquipmentDao,
    private val expenseCategoryDao: ExpenseCategoryDao,
    private val customerDao: CustomerDao,
    private val saleDao: SaleDao,
    private val expenseDao: ExpenseDao
) {
    suspend fun runAllChecks(): List<ValidationEngine.AuditResult> {
        val results = mutableListOf<ValidationEngine.AuditResult>()
        results += ValidationEngine.checkPartnerShareTotal(partnerDao.totalShareAnna() ?: 0.0)
        results += ValidationEngine.checkNoDuplicateNames(partnerDao.getAll().map { it.name }, "Partner")
        results += ValidationEngine.checkNoDuplicateNames(customerDao.getAll().map { it.name }, "Customer")

        val registerTotal = expenseDao.totalAmount()
        val summaryTotal = expenseDao.totalsByCategory().sumOf { it.total }
        results += ValidationEngine.checkExpenseReconciliation(registerTotal, summaryTotal)

        val salesErrors = saleDao.getAll().mapNotNull { FormulaPatterns.validateSalesRow(it) }
        results += ValidationEngine.AuditResult(
            "Sales Register row-level errors", salesErrors.isEmpty(),
            if (salesErrors.isNotEmpty()) "${salesErrors.size} row(s) flagged" else null
        )
        val expenseErrors = expenseDao.getAll().mapNotNull { FormulaPatterns.validateExpenseRow(it) }
        results += ValidationEngine.AuditResult(
            "Expense Register row-level errors", expenseErrors.isEmpty(),
            if (expenseErrors.isNotEmpty()) "${expenseErrors.size} row(s) flagged" else null
        )
        return results
    }
}

/** Delivery Challan / Money Receipt wiring (AUDIT §2.11 print templates — Phase 9). */
class PrintRepository(
    private val saleDao: SaleDao,
    private val extraPaymentDao: ExtraPaymentDao
) {
    /** Delivery Challan: pure read-only voucher lookup, creates no new data (matches source sheet exactly). */
    suspend fun findByVoucher(voucherNo: String) = saleDao.findByVoucher(voucherNo)

    /**
     * Decision D5 (finalized): Money Receipt -> Extra Payment link. When a Money Receipt is
     * saved with "Received Against" = Customer or Partner Due Collection, this records a
     * matching Extra Payment row so the Ledger's due calculation actually reflects the
     * receipt -- closing a real gap where Money Receipt was previously a disconnected print
     * form. Optional (caller decides whether to invoke this; see MoneyReceiptScreen's toggle).
     */
    suspend fun recordAsExtraPayment(partyType: String, partyName: String, date: String, amount: Double, remarks: String?) {
        if (partyType == "Customer") {
            extraPaymentDao.insertCustomerPayment(
                com.mbcerp.data.entity.CustomerExtraPaymentEntity(date = date, customerName = partyName, amount = amount, remarks = remarks)
            )
        } else if (partyType == "Partner") {
            extraPaymentDao.insertPartnerPayment(
                com.mbcerp.data.entity.PartnerExtraPaymentEntity(date = date, partnerName = partyName, amount = amount, remarks = remarks)
            )
        }
    }
}
