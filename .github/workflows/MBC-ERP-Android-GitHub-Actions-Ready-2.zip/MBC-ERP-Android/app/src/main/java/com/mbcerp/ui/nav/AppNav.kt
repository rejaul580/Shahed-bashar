package com.mbcerp.ui.nav

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mbcerp.MbcErpApp
import com.mbcerp.ui.asset.*
import com.mbcerp.ui.audit.*
import com.mbcerp.ui.cash.*
import com.mbcerp.ui.dashboard.*
import com.mbcerp.ui.expense.*
import com.mbcerp.ui.ledger.*
import com.mbcerp.ui.print.*
import com.mbcerp.ui.production.*
import com.mbcerp.ui.registers.*
import com.mbcerp.ui.sales.*
import com.mbcerp.ui.setup.SetupScreen
import com.mbcerp.ui.setup.SetupViewModel
import com.mbcerp.ui.setup.SetupViewModelFactory

/**
 * Full navigation graph (Phases 1-9). Bottom nav holds the 4 highest-traffic daily
 * screens (mirrors Dashboard's most-used Quick Menu links, AUDIT §5.2); everything
 * else (Ledgers, Registers, Cash Summary, Production, Asset, Audit, Print) lives
 * behind a "More" menu sheet -- the Android equivalent of the source Dashboard's full
 * 17-link Quick Menu, without needing a 12-tab bottom bar.
 */
private sealed class Dest(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : Dest("dashboard", "Dashboard", Icons.Default.Home)
    object SalesList : Dest("sales_list", "বিক্রয়", Icons.Default.ShoppingCart)
    object SalesEntry : Dest("sales_entry", "নতুন বিক্রয়", Icons.Default.Add)
    object ExpenseList : Dest("expense_list", "খরচ", Icons.Default.Receipt)
    object ExpenseEntry : Dest("expense_entry", "নতুন খরচ", Icons.Default.Add)
    object More : Dest("more", "আরও", Icons.Default.Menu)
    object Setup : Dest("setup", "Setup", Icons.Default.Settings)
    object Ledger : Dest("ledger", "Customer/Partner Ledger", Icons.Default.People)
    object Registers : Dest("registers", "Diesel/Coal/Majhi/Equipment", Icons.Default.LocalGasStation)
    object LedgerViewer : Dest("ledger_viewer", "Expense Summary / Ledger Viewer", Icons.Default.List)
    object CashSummary : Dest("cash_summary", "Cash Summary", Icons.Default.AccountBalance)
    object Production : Dest("production", "Production Register", Icons.Default.Factory)
    object AssetRegister : Dest("asset_register", "Asset Register", Icons.Default.Domain)
    object Audit : Dest("audit", "Audit / Validation", Icons.Default.FactCheck)
    object DeliveryChallan : Dest("delivery_challan", "Delivery Challan", Icons.Default.LocalShipping)
    object MoneyReceipt : Dest("money_receipt", "Money Receipt", Icons.Default.ReceiptLong)
    object Weather : Dest("weather", "Weather Alert", Icons.Default.Cloud)
    object Backup : Dest("backup", "Backup / Restore", Icons.Default.Backup)
}

private val bottomTabs = listOf(Dest.Dashboard, Dest.SalesList, Dest.ExpenseList, Dest.More)
private val moreMenuItems = listOf(
    Dest.Setup, Dest.Ledger, Dest.Registers, Dest.LedgerViewer, Dest.CashSummary,
    Dest.Production, Dest.AssetRegister, Dest.Audit, Dest.DeliveryChallan, Dest.MoneyReceipt,
    Dest.Weather, Dest.Backup
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavHost(app: MbcErpApp) {
    val navController = rememberNavController()
    var showMoreSheet by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                bottomTabs.forEach { dest ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true,
                        onClick = {
                            if (dest == Dest.More) {
                                showMoreSheet = true
                            } else {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Dashboard.route) {
                val vm: DashboardViewModel = viewModel(factory = DashboardViewModelFactory(app.dashboardRepository))
                DashboardScreen(vm)
            }
            composable(Dest.SalesList.route) {
                val vm: SalesListViewModel = viewModel(factory = SalesListViewModelFactory(app.salesRepository))
                SalesListScreen(vm, onAddClick = { navController.navigate(Dest.SalesEntry.route) })
            }
            composable(Dest.SalesEntry.route) {
                val vm: SalesEntryViewModel = viewModel(factory = SalesEntryViewModelFactory(app.salesRepository, app.setupRepository))
                SalesEntryScreen(vm, onSaved = { navController.popBackStack() })
            }
            composable(Dest.ExpenseList.route) {
                val vm: ExpenseListViewModel = viewModel(factory = ExpenseListViewModelFactory(app.expenseRepository))
                ExpenseListScreen(vm, onAddClick = { navController.navigate(Dest.ExpenseEntry.route) })
            }
            composable(Dest.ExpenseEntry.route) {
                val vm: ExpenseEntryViewModel = viewModel(factory = ExpenseEntryViewModelFactory(app.expenseRepository, app.setupRepository))
                ExpenseEntryScreen(vm, onSaved = { navController.popBackStack() })
            }
            composable(Dest.Setup.route) {
                val vm: SetupViewModel = viewModel(factory = SetupViewModelFactory(app.setupRepository))
                SetupScreen(vm)
            }
            composable(Dest.Ledger.route) {
                val vm: LedgerViewModel = viewModel(factory = LedgerViewModelFactory(app.ledgerRepository, app.setupRepository))
                LedgerScreen(vm)
            }
            composable(Dest.Registers.route) {
                val vm: RegistersViewModel = viewModel(factory = RegistersViewModelFactory(app.registerRepository, app.setupRepository))
                RegistersScreen(vm)
            }
            composable(Dest.LedgerViewer.route) {
                val vm: LedgerViewerViewModel = viewModel(factory = LedgerViewerViewModelFactory(app.registerRepository, app.setupRepository))
                LedgerViewerScreen(vm)
            }
            composable(Dest.CashSummary.route) {
                val vm: CashSummaryViewModel = viewModel(factory = CashSummaryViewModelFactory(app.cashSummaryRepository, app.setupRepository))
                CashSummaryScreen(vm)
            }
            composable(Dest.Production.route) {
                val vm: ProductionViewModel = viewModel(factory = ProductionViewModelFactory(app.productionRepository))
                ProductionScreen(vm)
            }
            composable(Dest.AssetRegister.route) {
                val vm: AssetRegisterViewModel = viewModel(factory = AssetRegisterViewModelFactory(app.assetRegisterRepository))
                AssetRegisterScreen(vm)
            }
            composable(Dest.Audit.route) {
                val vm: AuditViewModel = viewModel(factory = AuditViewModelFactory(app.auditRepository))
                AuditScreen(vm)
            }
            composable(Dest.DeliveryChallan.route) {
                val vm: DeliveryChallanViewModel = viewModel(factory = DeliveryChallanViewModelFactory(app.printRepository))
                DeliveryChallanScreen(vm)
            }
            composable(Dest.MoneyReceipt.route) {
                val vm: MoneyReceiptViewModel = viewModel(factory = MoneyReceiptViewModelFactory(app.printRepository))
                MoneyReceiptScreen(vm)
            }
            composable(Dest.Weather.route) {
                val vm: com.mbcerp.ui.weather.WeatherViewModel = viewModel(
                    factory = com.mbcerp.ui.weather.WeatherViewModelFactory(app.database.weatherDao())
                )
                com.mbcerp.ui.weather.WeatherScreen(vm)
            }
            composable(Dest.Backup.route) {
                val vm: com.mbcerp.ui.backup.BackupViewModel = viewModel(
                    factory = com.mbcerp.ui.backup.BackupViewModelFactory(app.localExportImport, app.driveBackupManager)
                )
                com.mbcerp.ui.backup.BackupScreen(vm, app.driveBackupManager)
            }
        }
    }

    if (showMoreSheet) {
        ModalBottomSheet(onDismissRequest = { showMoreSheet = false }) {
            LazyColumn {
                items(moreMenuItems) { dest ->
                    ListItem(
                        headlineContent = { Text(dest.label) },
                        leadingContent = { Icon(dest.icon, contentDescription = null) },
                        modifier = Modifier.clickable {
                            showMoreSheet = false
                            navController.navigate(dest.route) {
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    Divider()
                }
            }
        }
    }
}
