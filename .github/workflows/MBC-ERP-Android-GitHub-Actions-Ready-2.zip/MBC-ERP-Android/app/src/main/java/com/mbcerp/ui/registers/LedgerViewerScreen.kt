package com.mbcerp.ui.registers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.dao.CategoryTotal
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.repository.RegisterRepository
import com.mbcerp.repository.SetupRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * EXPENSE SUMMARY + LEDGER VIEWER (Phase 5, AUDIT §7.4, §2.5). This ONE screen replaces
 * Expense Summary + Ledger Viewer + all 41 HL_ hidden sheets from the source workbook --
 * they were all structurally the same "pick a category, see its filtered rows + total"
 * view (Pattern 3), so here it's a single category-picker driving one generic query
 * instead of 43 separate spreadsheet tabs.
 */
class LedgerViewerViewModel(
    private val registerRepository: RegisterRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    val categories = setupRepository.observeExpenseCategories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _categoryTotals = MutableStateFlow<List<CategoryTotal>>(emptyList())
    val categoryTotals: StateFlow<List<CategoryTotal>> = _categoryTotals

    private val _selectedRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val selectedRows: StateFlow<List<ExpenseEntity>> = _selectedRows

    fun loadSummary() = viewModelScope.launch { _categoryTotals.value = registerRepository.categoryTotals() }
    fun selectCategory(category: String) = viewModelScope.launch { _selectedRows.value = registerRepository.categoryRows(category) }
}

class LedgerViewerViewModelFactory(
    private val registerRepository: RegisterRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = LedgerViewerViewModel(registerRepository, setupRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LedgerViewerScreen(vm: LedgerViewerViewModel) {
    val categories by vm.categories.collectAsState()
    val totals by vm.categoryTotals.collectAsState()
    val rows by vm.selectedRows.collectAsState()
    var expanded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { vm.loadSummary() }

    Scaffold(topBar = { TopAppBar(title = { Text("Expense Summary / Ledger Viewer") }) }) { padding ->
        Column(Modifier.padding(padding).padding(12.dp)) {
            Text("সব Category-র Total (Grand Total: ৳${"%,.2f".format(totals.sumOf { it.total })})", style = MaterialTheme.typography.titleSmall)
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 220.dp)) {
                items(totals) { t ->
                    ListItem(
                        headlineContent = { Text(t.category) },
                        supportingContent = { Text("Total: ৳${"%,.2f".format(t.total)}  |  Paid: ৳${"%,.2f".format(t.paid)}  |  Due: ৳${"%,.2f".format(t.total - t.paid)}") },
                        modifier = Modifier.clickable_workaround(t.category) { c -> selected = c; vm.selectCategory(c) }
                    )
                    Divider()
                }
            }
            Spacer(Modifier.height(12.dp))
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(selected, {}, readOnly = true, label = { Text("অথবা Category বাছুন (Ledger Viewer)") }, modifier = Modifier.fillMaxWidth().menuAnchor())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    categories.forEach { c -> DropdownMenuItem(text = { Text(c.category) }, onClick = { selected = c.category; expanded = false; vm.selectCategory(c.category) }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("$selected -- ${rows.size} entries", style = MaterialTheme.typography.titleSmall)
            LazyColumn(Modifier.fillMaxWidth()) {
                items(rows) { r ->
                    ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, supportingContent = { Text(r.partyPaidTo ?: r.remarks ?: "") })
                    Divider()
                }
            }
        }
    }
}

// Small helper so the category-total list is also tappable without pulling in a second
// click-listener API for a one-off; keeps the composable list item declarative.
private fun Modifier.clickable_workaround(value: String, onClick: (String) -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable { onClick(value) })
