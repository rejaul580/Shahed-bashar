package com.mbcerp.weather

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.mbcerp.MainActivity

/**
 * Notification channel + builder for rain-risk alerts. Separate from WeatherAlertWorker
 * so the channel-creation/permission logic is unit-testable in isolation from the
 * WorkManager scheduling plumbing (though, like the rest of this file, actually posting
 * a notification requires a device -- not executed in this sandbox).
 */
object WeatherNotifier {
    const val CHANNEL_ID = "weather_rain_alert"
    private const val NOTIFICATION_ID = 5001

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "বৃষ্টির সতর্কতা (Rain Alert)", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ইটভাটার কাঁচা মাল ভিজে যাওয়া থেকে বাঁচাতে বৃষ্টির পূর্বাভাস সতর্কতা"
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    fun notify(context: Context, assessment: RainRiskCalculator.RiskAssessment) {
        ensureChannel(context)
        val openIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = when (assessment.level) {
            RainRiskCalculator.RiskLevel.SEVERE -> "⚠️ প্রবল বৃষ্টির সতর্কতা!"
            RainRiskCalculator.RiskLevel.HIGH -> "বৃষ্টির সম্ভাবনা বেশি"
            RainRiskCalculator.RiskLevel.MODERATE -> "বৃষ্টির সম্ভাবনা আছে"
            else -> "আবহাওয়া আপডেট"
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert) // placeholder icon; see README limitations
            .setContentTitle(title)
            .setContentText(assessment.reason)
            .setStyle(NotificationCompat.BigTextStyle().bigText(assessment.reason))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        // Caller (WeatherAlertWorker) is expected to have already checked
        // POST_NOTIFICATIONS permission on Android 13+; NotificationManagerCompat
        // silently no-ops if not granted.
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
    }
}
