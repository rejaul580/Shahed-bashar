package com.mbcerp.data.dao

import androidx.room.*
import com.mbcerp.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyProfileDao {
    @Query("DELETE FROM company_profile") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM company_profile WHERE id = 1")
    fun observe(): Flow<CompanyProfileEntity?>

    @Query("SELECT * FROM company_profile WHERE id = 1")
    suspend fun get(): CompanyProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CompanyProfileEntity)
}

@Dao
interface PartnerDao {
    @Query("DELETE FROM partners") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM partners WHERE isActive = 1 ORDER BY name")
    fun observeAll(): Flow<List<PartnerEntity>>

    @Query("SELECT * FROM partners WHERE isActive = 1 ORDER BY name")
    suspend fun getAll(): List<PartnerEntity>

    @Query("SELECT * FROM partners WHERE id = :id")
    suspend fun getById(id: Long): PartnerEntity?
    @Query("SELECT * FROM partners ORDER BY id") suspend fun getAllForBackup(): List<PartnerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: PartnerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<PartnerEntity>)

    @Update
    suspend fun update(entity: PartnerEntity)

    @Query("UPDATE partners SET isActive = 0 WHERE id = :id")
    suspend fun softDelete(id: Long) // Decision D7: no hard delete in Phase 1 UI

    @Query("SELECT SUM(shareAnna) FROM partners WHERE isActive = 1")
    suspend fun totalShareAnna(): Double?
}

@Dao
interface MajhiDao {
    @Query("DELETE FROM majhis") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM majhis WHERE isActive = 1 ORDER BY name")
    fun observeAll(): Flow<List<MajhiEntity>>
    @Query("SELECT * FROM majhis ORDER BY id") suspend fun getAllForBackup(): List<MajhiEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: MajhiEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<MajhiEntity>)
    @Update suspend fun update(e: MajhiEntity)
    @Query("UPDATE majhis SET isActive = 0 WHERE id = :id") suspend fun softDelete(id: Long)
}

@Dao
interface BrickTypeDao {
    @Query("DELETE FROM brick_types") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM brick_types ORDER BY sortOrder")
    fun observeAll(): Flow<List<BrickTypeEntity>>
    @Query("SELECT * FROM brick_types ORDER BY sortOrder")
    suspend fun getAll(): List<BrickTypeEntity>
    @Query("SELECT rate FROM brick_types WHERE category = :category COLLATE NOCASE LIMIT 1")
    suspend fun rateFor(category: String): Double?
    @Query("SELECT * FROM brick_types ORDER BY id") suspend fun getAllForBackup(): List<BrickTypeEntity> // mirrors Pattern 1 INDEX/MATCH rate lookup
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: BrickTypeEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<BrickTypeEntity>)
    @Update suspend fun update(e: BrickTypeEntity)
    @Delete suspend fun delete(e: BrickTypeEntity)
}

@Dao
interface EquipmentDao {
    @Query("DELETE FROM equipment") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM equipment WHERE isActive = 1 ORDER BY name")
    fun observeAll(): Flow<List<EquipmentEntity>>
    @Query("SELECT * FROM equipment ORDER BY id") suspend fun getAllForBackup(): List<EquipmentEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: EquipmentEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<EquipmentEntity>)
    @Update suspend fun update(e: EquipmentEntity)
    @Query("UPDATE equipment SET isActive = 0 WHERE id = :id") suspend fun softDelete(id: Long)
}

@Dao
interface ExpenseCategoryDao {
    @Query("DELETE FROM expense_categories") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM expense_categories WHERE isActive = 1 ORDER BY sortOrder")
    fun observeAll(): Flow<List<ExpenseCategoryEntity>>
    @Query("SELECT * FROM expense_categories WHERE isActive = 1 ORDER BY sortOrder")
    suspend fun getAll(): List<ExpenseCategoryEntity>
    @Query("SELECT * FROM expense_categories ORDER BY id") suspend fun getAllForBackup(): List<ExpenseCategoryEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: ExpenseCategoryEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<ExpenseCategoryEntity>)
    @Update suspend fun update(e: ExpenseCategoryEntity)
    @Query("UPDATE expense_categories SET isActive = 0 WHERE id = :id") suspend fun softDelete(id: Long)
}

@Dao
interface CustomerDao {
    @Query("DELETE FROM customers") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM customers WHERE isActive = 1 ORDER BY name")
    fun observeAll(): Flow<List<CustomerEntity>>
    @Query("SELECT * FROM customers WHERE isActive = 1 ORDER BY name")
    suspend fun getAll(): List<CustomerEntity>
    @Query("SELECT * FROM customers WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun findByName(name: String): CustomerEntity?
    @Query("SELECT * FROM customers ORDER BY id") suspend fun getAllForBackup(): List<CustomerEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: CustomerEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<CustomerEntity>)
    @Update suspend fun update(e: CustomerEntity)
    @Query("UPDATE customers SET isActive = 0 WHERE id = :id") suspend fun softDelete(id: Long)
}

@Dao
interface SaleDao {
    @Query("DELETE FROM sales") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM sales WHERE isDeleted = 0 ORDER BY date DESC, id DESC")
    fun observeAll(): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 ORDER BY date DESC, id DESC")
    suspend fun getAll(): List<SaleEntity>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 AND date = :date ORDER BY id")
    suspend fun getForDate(date: String): List<SaleEntity>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 AND partyType = :partyType COLLATE NOCASE AND partyName = :partyName COLLATE NOCASE ORDER BY date, id")
    suspend fun getForParty(partyType: String, partyName: String): List<SaleEntity>

    @Query("SELECT * FROM sales WHERE isDeleted = 0 AND voucherNo = :voucherNo LIMIT 1")
    suspend fun findByVoucher(voucherNo: String): SaleEntity?

    @Query("SELECT COALESCE(SUM(amount),0) FROM sales WHERE isDeleted = 0")
    suspend fun totalAmount(): Double

    @Query("SELECT COALESCE(SUM(quantity),0) FROM sales WHERE isDeleted = 0")
    suspend fun totalQuantity(): Double

    @Query("SELECT * FROM sales ORDER BY id") suspend fun getAllForBackup(): List<SaleEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: SaleEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<SaleEntity>)
    @Update suspend fun update(e: SaleEntity)
    @Query("UPDATE sales SET isDeleted = 1 WHERE id = :id") suspend fun softDelete(id: Long)
}

@Dao
interface ExpenseDao {
    @Query("DELETE FROM expenses") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM expenses WHERE isDeleted = 0 ORDER BY date DESC, id DESC")
    fun observeAll(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE isDeleted = 0 ORDER BY date DESC, id DESC")
    suspend fun getAll(): List<ExpenseEntity>

    @Query("SELECT * FROM expenses WHERE isDeleted = 0 AND date = :date ORDER BY id")
    suspend fun getForDate(date: String): List<ExpenseEntity>

    @Query("SELECT * FROM expenses WHERE isDeleted = 0 AND category = :category COLLATE NOCASE ORDER BY date, id")
    suspend fun getForCategory(category: String): List<ExpenseEntity>       // replaces all 41 HL_ sheets + Ledger Viewer

    @Query("SELECT * FROM expenses WHERE isDeleted = 0 AND partyPaidTo = :name COLLATE NOCASE ORDER BY date, id")
    suspend fun getForParty(name: String): List<ExpenseEntity>              // Majhi Ledger / Equipment Register

    @Query("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE isDeleted = 0")
    suspend fun totalAmount(): Double

    @Query("""
        SELECT category, COALESCE(SUM(amount),0) as total, COALESCE(SUM(paidCash),0) as paid
        FROM expenses WHERE isDeleted = 0 GROUP BY category ORDER BY category
    """)
    suspend fun totalsByCategory(): List<CategoryTotal>

    @Query("SELECT * FROM expenses ORDER BY id") suspend fun getAllForBackup(): List<ExpenseEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: ExpenseEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<ExpenseEntity>)
    @Update suspend fun update(e: ExpenseEntity)
    @Query("UPDATE expenses SET isDeleted = 1 WHERE id = :id") suspend fun softDelete(id: Long)
}

data class CategoryTotal(val category: String, val total: Double, val paid: Double)

@Dao
interface ExtraPaymentDao {
    @Query("DELETE FROM customer_extra_payments") suspend fun deleteAllCustomerPaymentsForBackup()
    @Query("DELETE FROM partner_extra_payments") suspend fun deleteAllPartnerPaymentsForBackup()

    @Query("SELECT * FROM customer_extra_payments WHERE isDeleted = 0 AND customerName = :name ORDER BY date")
    suspend fun customerPayments(name: String): List<CustomerExtraPaymentEntity>

    @Query("SELECT COALESCE(SUM(amount),0) FROM customer_extra_payments WHERE isDeleted = 0 AND customerName = :name")
    suspend fun customerTotal(name: String): Double

    @Query("SELECT * FROM partner_extra_payments WHERE isDeleted = 0 AND partnerName = :name ORDER BY date")
    suspend fun partnerPayments(name: String): List<PartnerExtraPaymentEntity>

    @Query("SELECT COALESCE(SUM(amount),0) FROM partner_extra_payments WHERE isDeleted = 0 AND partnerName = :name")
    suspend fun partnerTotal(name: String): Double

    @Query("SELECT * FROM customer_extra_payments ORDER BY id") suspend fun getAllCustomerPaymentsForBackup(): List<CustomerExtraPaymentEntity>
    @Query("SELECT * FROM partner_extra_payments ORDER BY id") suspend fun getAllPartnerPaymentsForBackup(): List<PartnerExtraPaymentEntity>
    @Insert suspend fun insertCustomerPayment(e: CustomerExtraPaymentEntity): Long
    @Insert suspend fun insertPartnerPayment(e: PartnerExtraPaymentEntity): Long
    @Insert suspend fun insertAllCustomerPayments(e: List<CustomerExtraPaymentEntity>)
    @Insert suspend fun insertAllPartnerPayments(e: List<PartnerExtraPaymentEntity>)
}

@Dao
interface StockDao {
    @Query("DELETE FROM diesel_issues") suspend fun deleteAllDieselIssuesForBackup()
    @Query("DELETE FROM coal_usages") suspend fun deleteAllCoalUsagesForBackup()
    @Query("DELETE FROM equipment_working_hours") suspend fun deleteAllWorkingHoursForBackup()

    @Query("SELECT * FROM diesel_issues ORDER BY id") suspend fun getAllDieselIssuesForBackup(): List<DieselIssueEntity>
    @Query("SELECT * FROM coal_usages ORDER BY id") suspend fun getAllCoalUsagesForBackup(): List<CoalUsageEntity>
    @Query("SELECT * FROM equipment_working_hours ORDER BY id") suspend fun getAllWorkingHoursForBackup(): List<EquipmentWorkingHourEntity>
    @Insert suspend fun insertDieselIssue(e: DieselIssueEntity): Long
    @Insert suspend fun insertAllDieselIssues(e: List<DieselIssueEntity>)
    @Query("SELECT COALESCE(SUM(quantity),0) FROM diesel_issues WHERE isDeleted = 0")
    suspend fun totalDieselIssued(): Double

    @Insert suspend fun insertCoalUsage(e: CoalUsageEntity): Long
    @Insert suspend fun insertAllCoalUsages(e: List<CoalUsageEntity>)
    @Query("SELECT COALESCE(SUM(quantity),0) FROM coal_usages WHERE isDeleted = 0")
    suspend fun totalCoalUsed(): Double

    @Insert suspend fun insertWorkingHour(e: EquipmentWorkingHourEntity): Long
    @Insert suspend fun insertAllWorkingHours(e: List<EquipmentWorkingHourEntity>)
    @Query("SELECT COALESCE(SUM(hours),0) FROM equipment_working_hours WHERE isDeleted = 0 AND equipmentName = :name")
    suspend fun totalHoursFor(name: String): Double
}

@Dao
interface ProductionDao {
    @Query("DELETE FROM production_entries") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM production_entries WHERE isDeleted = 0 ORDER BY date")
    fun observeAll(): Flow<List<ProductionEntryEntity>>
    @Query("SELECT * FROM production_entries ORDER BY id") suspend fun getAllForBackup(): List<ProductionEntryEntity>
    @Insert suspend fun insert(e: ProductionEntryEntity): Long
    @Insert suspend fun insertAll(e: List<ProductionEntryEntity>)
    @Query("SELECT COALESCE(SUM(loadedToKiln),0) FROM production_entries WHERE isDeleted = 0")
    suspend fun totalLoadedToKiln(): Double
}

@Dao
interface AssetRegisterDao {
    @Query("DELETE FROM asset_register") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM asset_register WHERE isDeleted = 0 ORDER BY date")
    fun observeAll(): Flow<List<AssetRegisterEntity>>
    @Query("SELECT * FROM asset_register ORDER BY id") suspend fun getAllForBackup(): List<AssetRegisterEntity>
    @Insert suspend fun insert(e: AssetRegisterEntity): Long
    @Insert suspend fun insertAll(e: List<AssetRegisterEntity>)
}

@Dao
interface OldDueCollectionDao {
    @Query("DELETE FROM old_due_collections") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM old_due_collections ORDER BY id") suspend fun getAllForBackup(): List<OldDueCollectionEntity>
    @Query("SELECT * FROM old_due_collections WHERE isDeleted = 0 ORDER BY date")
    fun observeAll(): Flow<List<OldDueCollectionEntity>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM old_due_collections WHERE isDeleted = 0")
    suspend fun totalCollected(): Double
    @Insert suspend fun insert(e: OldDueCollectionEntity): Long
    @Insert suspend fun insertAll(e: List<OldDueCollectionEntity>)
}

@Dao
interface CashSummaryAdjustmentDao {
    @Query("DELETE FROM cash_summary_adjustments") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM cash_summary_adjustments ORDER BY season")
    suspend fun getAllForBackup(): List<CashSummaryAdjustmentEntity>
    @Query("SELECT * FROM cash_summary_adjustments WHERE season = :season")
    suspend fun get(season: String): CashSummaryAdjustmentEntity?
    @Query("SELECT * FROM cash_summary_adjustments WHERE season = :season")
    fun observe(season: String): Flow<CashSummaryAdjustmentEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e: CashSummaryAdjustmentEntity)
}

@Dao
interface AppUserDao {
    @Query("DELETE FROM app_users") suspend fun deleteAllForBackup()

    @Query("SELECT * FROM app_users WHERE username = :username AND isActive = 1 LIMIT 1")
    suspend fun findByUsername(username: String): AppUserEntity?
    @Query("SELECT * FROM app_users ORDER BY id") suspend fun getAllForBackup(): List<AppUserEntity>
    @Query("SELECT COUNT(*) FROM app_users WHERE isActive = 1")
    suspend fun countActiveUsers(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(e: List<AppUserEntity>)
    @Insert suspend fun insert(e: AppUserEntity): Long
    @Update suspend fun update(e: AppUserEntity)
}
