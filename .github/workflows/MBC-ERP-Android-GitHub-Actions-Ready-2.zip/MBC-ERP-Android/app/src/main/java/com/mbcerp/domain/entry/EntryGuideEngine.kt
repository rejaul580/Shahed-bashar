package com.mbcerp.domain.entry

import com.mbcerp.data.entity.SaleEntity

/**
 * ENTRY GUIDE ENGINE (AUDIT REPORT §6.1 — verbatim translation of the "Entry Guide"
 * sheet's 7 documented real-world scenarios). The original workbook's central rule:
 *
 *   Column M (Cash Received) IS the real cash movement. M positive = money came in
 *   (due decreases). M negative = money went out (due increases). K, L, M are plain
 *   typed values in Excel — never formulas — and the person typing has to remember
 *   the sign by hand. This engine turns that tribal knowledge into a guided UI mode
 *   picker so a data-entry clerk cannot accidentally get the sign wrong.
 *
 * Every EntryMode below maps 1:1 to a row of the AUDIT §6.1 table. Modes 6 and 7 do
 * NOT produce a SaleEntity at all — they belong on the Expense Entry screen instead
 * (see ui/expense/ExpenseEntryScreen.kt), exactly as the source sheet describes.
 */
sealed class EntryMode(val label: String, val description: String) {

    object RegularSale : EntryMode(
        "সাধারণ বিক্রয় (Regular Sale)",
        "ইট বিক্রি হলো, দাম বসান, ক্যাশ পেলে ধনাত্মক (+) সংখ্যা লিখুন।"
    )

    object PartnerDueSettlement : EntryMode(
        "Partner/Driver-এর পুরনো Due শোধ (Due Settlement)",
        "শুধু টাকার পরিমাণ ধনাত্মক (+) লিখুন — ইটের বিবরণ ফাঁকা থাকবে।"
    )

    object AdvanceToPartner : EntryMode(
        "Partner-কে অগ্রিম/ঋণ প্রদান (Advance / Loan Out)",
        "টাকা মাঠ থেকে বের হচ্ছে — পরিমাণ ঋণাত্মক (−) লিখুন, ইটের বিবরণ ফাঁকা থাকবে।"
    )

    object AdvanceSale : EntryMode(
        "ভবিষ্যতের ইটের জন্য Advance",
        "টাকা ধনাত্মক (+), Sale Type = Advance Sale, ইটের বিবরণ ফাঁকা থাকবে।"
    )

    object DueTransferBetweenPartners : EntryMode(
        "দুই Partner-এর মধ্যে Due স্থানান্তর (কোনো cash movement নেই)",
        "দুইটা row লাগবে — একটাতে ঋণাত্মক (−), অন্যটাতে ধনাত্মক (+), একই পরিমাণ।"
    )

    companion object {
        val salesEntryModes = listOf(RegularSale, PartnerDueSettlement, AdvanceToPartner, AdvanceSale, DueTransferBetweenPartners)
    }
}

/** Everything a user types into the guided Sales Entry form, before it becomes a SaleEntity. */
data class SalesEntryInput(
    val mode: EntryMode,
    val date: String,
    val voucherNo: String?,
    val truckNo: String?,
    val partyType: String,       // "Customer" | "Partner"
    val partyName: String,
    val location: String? = null,
    val sideParty: String? = null,
    val brickCategory: String? = null,
    val quantity: Double = 0.0,
    val rate: Double = 0.0,
    val amount: Double = 0.0,
    val cashAmount: Double = 0.0, // always entered as a positive number by the user; sign is applied by the engine
    val remarks: String? = null
)

object EntryGuideEngine {

    /**
     * Builds the correct SaleEntity (or entities, for the 2-row due-transfer case) from a
     * guided-mode input, applying the exact sign/blank-field rules documented in AUDIT §6.1.
     * Returns a list because DueTransferBetweenPartners produces 2 rows from one form.
     */
    fun buildSaleEntities(input: SalesEntryInput, counterpartyName: String? = null): List<SaleEntity> {
        val base = SaleEntity(
            date = input.date,
            voucherNo = input.voucherNo,
            truckNo = input.truckNo,
            partyType = input.partyType,
            partyName = input.partyName,
            location = input.location,
            sideParty = input.sideParty,
            brickCategory = input.brickCategory ?: "",
            remarks = input.remarks
        )
        return when (input.mode) {
            EntryMode.RegularSale -> listOf(
                base.copy(
                    brickCategory = input.brickCategory ?: "",
                    quantity = input.quantity,
                    rate = input.rate,
                    amount = input.amount,
                    cashReceived = input.cashAmount, // (+) if received now, 0 if fully on credit
                    saleType = "Regular Sale"
                )
            )
            EntryMode.PartnerDueSettlement -> listOf(
                base.copy(cashReceived = kotlin.math.abs(input.cashAmount), saleType = null)
            )
            EntryMode.AdvanceToPartner -> listOf(
                base.copy(cashReceived = -kotlin.math.abs(input.cashAmount), saleType = null)
            )
            EntryMode.AdvanceSale -> listOf(
                base.copy(cashReceived = kotlin.math.abs(input.cashAmount), saleType = "Advance Sale")
            )
            EntryMode.DueTransferBetweenPartners -> {
                requireNotNull(counterpartyName) { "Due transfer needs a second partner name" }
                val amt = kotlin.math.abs(input.cashAmount)
                listOf(
                    base.copy(cashReceived = -amt, saleType = null),
                    base.copy(partyName = counterpartyName, cashReceived = amt, saleType = null)
                )
            }
        }
    }
}
