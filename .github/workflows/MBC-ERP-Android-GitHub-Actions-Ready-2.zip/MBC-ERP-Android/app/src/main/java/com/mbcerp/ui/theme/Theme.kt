package com.mbcerp.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = BrickPrimary, onPrimary = BrickOnPrimary,
    primaryContainer = BrickPrimaryContainer, onPrimaryContainer = BrickOnPrimaryContainer,
    secondary = ClaySecondary, onSecondary = ClayOnSecondary,
    secondaryContainer = ClaySecondaryContainer, onSecondaryContainer = ClayOnSecondaryContainer,
    tertiary = EmberTertiary, onTertiary = EmberOnTertiary,
    tertiaryContainer = EmberTertiaryContainer, onTertiaryContainer = EmberOnTertiaryContainer,
    background = LightBackground, onBackground = LightOnBackground,
    surface = LightSurface, onSurface = LightOnBackground,
    surfaceVariant = LightSurfaceVariant, onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    error = ErrorRed, onError = OnErrorRed, errorContainer = ErrorContainer, onErrorContainer = OnErrorContainer,
)

private val DarkColors = darkColorScheme(
    primary = BrickPrimaryDark, onPrimary = BrickOnPrimaryDark,
    primaryContainer = BrickPrimaryContainerDark, onPrimaryContainer = BrickOnPrimaryContainerDark,
    secondary = ClaySecondaryDark, onSecondary = ClayOnSecondaryDark,
    secondaryContainer = ClaySecondaryContainerDark, onSecondaryContainer = ClayOnSecondaryContainerDark,
    background = DarkBackground, onBackground = DarkOnBackground,
    surface = DarkSurface, onSurface = DarkOnBackground,
    surfaceVariant = DarkSurfaceVariant, onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    error = ErrorRed, onError = OnErrorRed, errorContainer = ErrorContainer, onErrorContainer = OnErrorContainer,
)

/**
 * App-wide theme (replaces the old bare `MaterialTheme { ... }` call in MainActivity,
 * which was rendering with Compose's default purple Material palette everywhere --
 * every screen in the app inherits this automatically, no per-screen changes needed).
 *
 * Deliberately does NOT opt into Android 12+ dynamic color (Material You) by default:
 * this is a business/accounting app where color carries meaning (brand identity,
 * consistent "due" vs "paid" cues) that should not shift with the user's wallpaper.
 */
@Composable
fun MbcErpTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MbcTypography,
        shapes = MbcShapes,
        content = content
    )
}
