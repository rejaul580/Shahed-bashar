package com.mbcerp.backup

import android.accounts.Account
import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/**
 * Real Google Drive REST API v3 wrapper. See BackupModels.kt's top comment for the
 * one-time Google Cloud Console setup a developer must do before this compiles+runs
 * against a real account -- that setup cannot be performed from this sandbox.
 *
 * NOT NETWORK-TESTED (same caveat as WeatherApiClient): no internet access here.
 * The Drive API call shapes below (files().create, files().list, files().get) match
 * the officially documented Java Drive client library usage, but have not been
 * executed against a live account.
 */
class GoogleDriveBackupManager(private val context: Context) {

    private val backupFolderName = "MBC ERP Backups"

    fun signInClient(): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(com.google.android.gms.common.api.Scope(DriveScopes.DRIVE_FILE))
            .build()
        return GoogleSignIn.getClient(context, options)
    }

    fun lastSignedInAccount(): GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)

    private fun driveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(context, listOf(DriveScopes.DRIVE_FILE))
        credential.selectedAccount = account.account
        return Drive.Builder(NetHttpTransport(), GsonFactory.getDefaultInstance(), credential)
            .setApplicationName("MBC Brickfield ERP")
            .build()
    }

    private fun ensureBackupFolder(drive: Drive): String {
        val existing = drive.files().list()
            .setQ("name = '$backupFolderName' and mimeType = 'application/vnd.google-apps.folder' and trashed = false")
            .setSpaces("drive")
            .execute()
        existing.files.firstOrNull()?.let { return it.id }

        val folderMetadata = DriveFile().apply {
            name = backupFolderName
            mimeType = "application/vnd.google-apps.folder"
        }
        return drive.files().create(folderMetadata).setFields("id").execute().id
    }

    /** Uploads one timestamped backup JSON file. Returns the Drive file id. */
    fun uploadBackup(account: GoogleSignInAccount, bundle: BackupBundle): String {
        val drive = driveService(account)
        val folderId = ensureBackupFolder(drive)

        val bundleJson = JSONObject().apply {
            put("schemaVersion", bundle.manifest.schemaVersion)
            put("exportedAtMillis", bundle.manifest.exportedAtMillis)
            put("appVersionName", bundle.manifest.appVersionName)
            put("tableRowCounts", JSONObject(bundle.manifest.tableRowCounts as Map<*, *>))
            put("tables", JSONObject(bundle.tablesJson as Map<*, *>))
        }.toString()

        val fileName = "mbc_erp_backup_${bundle.manifest.exportedAtMillis}.json"
        val metadata = DriveFile().apply {
            name = fileName
            parents = listOf(folderId)
        }
        val content = com.google.api.client.http.ByteArrayContent("application/json", bundleJson.toByteArray(Charsets.UTF_8))
        val uploaded = drive.files().create(metadata, content).setFields("id").execute()
        return uploaded.id
    }

    /** Lists available backups, newest first, for the restore picker UI. */
    fun listBackups(account: GoogleSignInAccount): List<Pair<String, String>> { // id to name
        val drive = driveService(account)
        val folderId = ensureBackupFolder(drive)
        val result = drive.files().list()
            .setQ("'$folderId' in parents and trashed = false")
            .setOrderBy("createdTime desc")
            .setFields("files(id, name)")
            .execute()
        return result.files.map { it.id to it.name }
    }

    fun downloadBackup(account: GoogleSignInAccount, fileId: String): BackupBundle {
        val drive = driveService(account)
        val output = ByteArrayOutputStream()
        drive.files().get(fileId).executeMediaAndDownloadTo(output)
        val json = JSONObject(output.toString(Charsets.UTF_8.name()))

        val rowCounts = mutableMapOf<String, Int>()
        json.getJSONObject("tableRowCounts").let { rc -> rc.keys().forEach { k -> rowCounts[k] = rc.getInt(k) } }
        val tables = mutableMapOf<String, String>()
        json.getJSONObject("tables").let { t -> t.keys().forEach { k -> tables[k] = t.getString(k) } }

        return BackupBundle(
            manifest = BackupManifest(
                schemaVersion = json.getInt("schemaVersion"),
                exportedAtMillis = json.getLong("exportedAtMillis"),
                appVersionName = json.getString("appVersionName"),
                tableRowCounts = rowCounts
            ),
            tablesJson = tables
        )
    }
}
