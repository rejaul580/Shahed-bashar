package com.mbcerp.ui.asset

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.AssetRegisterEntity
import com.mbcerp.repository.AssetRegisterRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/** ASSET REGISTER (Phase 8, AUDIT §2.10). Manual-entry only -- no auto cross-sheet sync, matches source. */
class AssetRegisterViewModel(private val repo: AssetRegisterRepository) : ViewModel() {
    val entries = repo.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun addEntry(e: AssetRegisterEntity) = viewModelScope.launch { repo.addEntry(e) }
}

class AssetRegisterViewModelFactory(private val repo: AssetRegisterRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AssetRegisterViewModel(repo) as T
}

@Composable
fun AssetRegisterScreen(vm: AssetRegisterViewModel) {
    val entries by vm.entries.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Asset Register (${entries.size})") }) },
        floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Default.Add, contentDescription = "Add") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize()) {
            items(entries) { e ->
                ListItem(
                    headlineContent = { Text(e.description ?: e.assetType ?: "-") },
                    supportingContent = { Text("${e.date ?: "-"}  |  ${e.assetType ?: "-"}  |  ৳${e.purchaseAmount}  |  ${e.location ?: "-"}") }
                )
                Divider()
            }
        }
    }

    if (showDialog) {
        var date by remember { mutableStateOf(LocalDate.now().toString()) }
        var assetType by remember { mutableStateOf("Land") }
        var description by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("0") }
        var owners by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন Asset Entry") },
            text = {
                Column {
                    OutlinedTextField(date, { date = it }, label = { Text("Date") })
                    OutlinedTextField(assetType, { assetType = it }, label = { Text("Asset Type") })
                    OutlinedTextField(description, { description = it }, label = { Text("Description") })
                    OutlinedTextField(location, { location = it }, label = { Text("Location") })
                    OutlinedTextField(amount, { amount = it }, label = { Text("Purchase Amount") })
                    OutlinedTextField(owners, { owners = it }, label = { Text("Owners") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addEntry(
                        AssetRegisterEntity(
                            date = date, assetType = assetType, description = description.ifBlank { null },
                            location = location.ifBlank { null }, purchaseAmount = amount.toDoubleOrNull() ?: 0.0,
                            owners = owners.ifBlank { null }
                        )
                    )
                    showDialog = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }
}
