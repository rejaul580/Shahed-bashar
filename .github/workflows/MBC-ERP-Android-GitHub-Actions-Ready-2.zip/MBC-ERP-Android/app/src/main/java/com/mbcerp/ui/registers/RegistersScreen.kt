package com.mbcerp.ui.registers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.dao.CategoryTotal
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.domain.calc.StockCalculator
import com.mbcerp.repository.RegisterRepository
import com.mbcerp.repository.SetupRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * DIESEL / COAL / MAJHI / EQUIPMENT REGISTER SCREEN (Phase 4, AUDIT §2.5, §2.6).
 * Excel had 4 nearly-identical sheets for this; here it's one tab-based screen driving
 * the same RegisterRepository queries -- exactly mirroring the "filtered-row-puller"
 * pattern (AUDIT §4.1 Pattern 3) that made those 4 sheets structurally interchangeable.
 */
class RegistersViewModel(
    private val registerRepository: RegisterRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    val majhis = registerRepository.observeMajhis().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val equipment = registerRepository.observeEquipment().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _dieselStock = MutableStateFlow<StockCalculator.StockResult?>(null)
    val dieselStock: StateFlow<StockCalculator.StockResult?> = _dieselStock
    private val _dieselRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val dieselRows: StateFlow<List<ExpenseEntity>> = _dieselRows

    private val _coalStock = MutableStateFlow<StockCalculator.StockResult?>(null)
    val coalStock: StateFlow<StockCalculator.StockResult?> = _coalStock
    private val _coalRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val coalRows: StateFlow<List<ExpenseEntity>> = _coalRows

    private val _majhiRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val majhiRows: StateFlow<List<ExpenseEntity>> = _majhiRows
    private val _majhiTotal = MutableStateFlow(0.0)
    val majhiTotal: StateFlow<Double> = _majhiTotal

    private val _equipRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val equipRows: StateFlow<List<ExpenseEntity>> = _equipRows
    private val _equipHours = MutableStateFlow(0.0)
    val equipHours: StateFlow<Double> = _equipHours
    private val _equipPaid = MutableStateFlow(0.0)
    val equipPaid: StateFlow<Double> = _equipPaid

    fun loadDiesel() = viewModelScope.launch {
        _dieselStock.value = registerRepository.dieselStock()
        _dieselRows.value = registerRepository.dieselPurchaseRows()
    }

    fun loadCoal() = viewModelScope.launch {
        _coalStock.value = registerRepository.coalStock()
        _coalRows.value = registerRepository.coalPurchaseRows()
    }

    fun loadMajhi(name: String) = viewModelScope.launch {
        _majhiRows.value = registerRepository.majhiLedgerRows(name)
        _majhiTotal.value = registerRepository.majhiTotalAdvance(name)
    }

    fun loadEquipment(name: String) = viewModelScope.launch {
        _equipRows.value = registerRepository.equipmentLedgerRows(name)
        _equipHours.value = registerRepository.equipmentTotalHours(name)
        _equipPaid.value = registerRepository.equipmentTotalPaid(name)
    }
}

class RegistersViewModelFactory(
    private val registerRepository: RegisterRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = RegistersViewModel(registerRepository, setupRepository) as T
}

@Composable
fun RegistersScreen(vm: RegistersViewModel) {
    val tabs = listOf("Diesel", "Coal", "Majhi Ledger", "Equipment")
    var tab by remember { mutableStateOf(0) }

    Scaffold(topBar = { TopAppBar(title = { Text("Diesel / Coal / Majhi / Equipment") }) }) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> DieselTab(vm)
                1 -> CoalTab(vm)
                2 -> MajhiTab(vm)
                3 -> EquipmentTab(vm)
            }
        }
    }
}

@Composable
private fun DieselTab(vm: RegistersViewModel) {
    val stock by vm.dieselStock.collectAsState()
    val rows by vm.dieselRows.collectAsState()
    LaunchedEffect(Unit) { vm.loadDiesel() }
    Column(Modifier.padding(12.dp)) {
        stock?.let {
            Text("Total Purchased: ${it.purchasedOrProduced} L  |  Cost: ৳${it.totalCost}  |  Stock: ${it.currentStock} L", style = MaterialTheme.typography.titleSmall)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, supportingContent = { Text(r.remarks ?: "") }); Divider() } }
    }
}

@Composable
private fun CoalTab(vm: RegistersViewModel) {
    val stock by vm.coalStock.collectAsState()
    val rows by vm.coalRows.collectAsState()
    LaunchedEffect(Unit) { vm.loadCoal() }
    Column(Modifier.padding(12.dp)) {
        stock?.let {
            Text("Total Purchased: ${it.purchasedOrProduced}  |  Cost: ৳${it.totalCost}  |  Stock: ${it.currentStock}", style = MaterialTheme.typography.titleSmall)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, supportingContent = { Text(r.remarks ?: "") }); Divider() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MajhiTab(vm: RegistersViewModel) {
    val majhis by vm.majhis.collectAsState()
    val rows by vm.majhiRows.collectAsState()
    val total by vm.majhiTotal.collectAsState()
    var selected by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.padding(12.dp)) {
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(selected, {}, readOnly = true, label = { Text("Majhi বাছুন") }, modifier = Modifier.fillMaxWidth().menuAnchor())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                majhis.forEach { m -> DropdownMenuItem(text = { Text(m.name) }, onClick = { selected = m.name; expanded = false; vm.loadMajhi(m.name) }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Total Advance/Payment: ৳${"%,.2f".format(total)}", style = MaterialTheme.typography.titleSmall)
        Text("নোট: majhi advance এখানে informational -- season-শেষে ম্যানুয়ালি settle করা হয় (Excel-এর নিয়ম অনুযায়ী), Due-এর সাথে auto-deduct হয় না।", style = MaterialTheme.typography.bodySmall)
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }); Divider() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EquipmentTab(vm: RegistersViewModel) {
    val equipment by vm.equipment.collectAsState()
    val rows by vm.equipRows.collectAsState()
    val hours by vm.equipHours.collectAsState()
    val paid by vm.equipPaid.collectAsState()
    var selected by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.padding(12.dp)) {
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(selected, {}, readOnly = true, label = { Text("Equipment বাছুন") }, modifier = Modifier.fillMaxWidth().menuAnchor())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                equipment.forEach { e -> DropdownMenuItem(text = { Text(e.name) }, onClick = { selected = e.name; expanded = false; vm.loadEquipment(e.name) }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Total Paid: ৳${"%,.2f".format(paid)}  |  Total Working Hours: $hours", style = MaterialTheme.typography.titleSmall)
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }); Divider() } }
    }
}
