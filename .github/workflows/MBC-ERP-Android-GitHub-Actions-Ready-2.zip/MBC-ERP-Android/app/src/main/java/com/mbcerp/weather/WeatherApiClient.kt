package com.mbcerp.weather

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Live forecast fetch (item 5). Uses Open-Meteo (https://open-meteo.com) because it is
 * free, requires no API key, and has a simple JSON REST API -- appropriate for a
 * small offline-first brickfield app that should not require the owner to manage API
 * credentials.
 *
 * NOT NETWORK-TESTED: this sandbox has no internet access (confirmed: bash_tool's
 * network is disabled, outbound requests return HTTP 403 host_not_allowed). This
 * class has never actually been executed against the live Open-Meteo endpoint. The
 * URL format and JSON field names below are per Open-Meteo's public documentation as
 * of this app's design, but have not been runtime-verified. Verify on a real device
 * with internet before relying on it.
 */
class WeatherApiClient {

    /** Plain HttpURLConnection (no OkHttp/Retrofit dependency) to keep this feature's footprint small. */
    fun fetchHourlyForecast(latitude: Double, longitude: Double): List<RainRiskCalculator.HourlyForecastPoint> {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude" +
            "&hourly=precipitation_probability,precipitation&forecast_days=2&timezone=auto"
        )
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        try {
            val responseCode = connection.responseCode
            if (responseCode != 200) throw WeatherFetchException("HTTP $responseCode from Open-Meteo")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            return parseResponse(body)
        } finally {
            connection.disconnect()
        }
    }

    internal fun parseResponse(body: String): List<RainRiskCalculator.HourlyForecastPoint> {
        val json = JSONObject(body)
        val hourly = json.getJSONObject("hourly")
        val probs = hourly.getJSONArray("precipitation_probability")
        val precs = hourly.getJSONArray("precipitation")
        val points = mutableListOf<RainRiskCalculator.HourlyForecastPoint>()
        for (i in 0 until probs.length()) {
            points.add(
                RainRiskCalculator.HourlyForecastPoint(
                    hoursFromNow = i,
                    precipitationProbabilityPercent = probs.optInt(i, 0),
                    precipitationMm = precs.optDouble(i, 0.0)
                )
            )
        }
        return points
    }
}

class WeatherFetchException(message: String) : Exception(message)
