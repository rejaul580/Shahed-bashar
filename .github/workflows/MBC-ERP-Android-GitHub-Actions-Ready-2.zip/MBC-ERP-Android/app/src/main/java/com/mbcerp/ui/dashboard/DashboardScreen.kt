package com.mbcerp.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.repository.DashboardRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/** DASHBOARD + DAILY REPORT (AUDIT §2.8). Pure aggregation, no data entry. */
class DashboardViewModel(private val dashboardRepository: DashboardRepository) : ViewModel() {
    private val _kpis = MutableStateFlow<DashboardRepository.DashboardKpis?>(null)
    val kpis: StateFlow<DashboardRepository.DashboardKpis?> = _kpis

    private val _dailySales = MutableStateFlow<List<SaleEntity>>(emptyList())
    val dailySales: StateFlow<List<SaleEntity>> = _dailySales
    private val _dailyExpenses = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val dailyExpenses: StateFlow<List<ExpenseEntity>> = _dailyExpenses

    fun load() = viewModelScope.launch { _kpis.value = dashboardRepository.kpis() }

    fun loadDailyReport(date: LocalDate) = viewModelScope.launch {
        _dailySales.value = dashboardRepository.dailySales(date.toString())
        _dailyExpenses.value = dashboardRepository.dailyExpenses(date.toString())
    }
}

class DashboardViewModelFactory(private val dashboardRepository: DashboardRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = DashboardViewModel(dashboardRepository) as T
}

private data class Kpi(val label: String, val value: Double, val icon: ImageVector, val emphasis: Emphasis = Emphasis.NEUTRAL)
private enum class Emphasis { POSITIVE, NEGATIVE, NEUTRAL }

@Composable
fun DashboardScreen(vm: DashboardViewModel) {
    val kpis by vm.kpis.collectAsState()
    var showDaily by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.load() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dashboard") },
                actions = {
                    TextButton(onClick = { showDaily = true; vm.loadDailyReport(LocalDate.now()) }) {
                        Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("আজকের রিপোর্ট")
                    }
                }
            )
        }
    ) { padding ->
        if (kpis == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
            return@Scaffold
        }
        val k = kpis!!

        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Hero card -- the one number the owner checks first.
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.width(8.dp))
                        Text("Cash In Hand", color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "৳${"%,.2f".format(k.cashInHand)}",
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 32.sp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("সংক্ষিপ্ত হিসাব", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))

            val items = listOf(
                Kpi("Total Capital", k.totalCapital, Icons.Default.AccountBalance),
                Kpi("Total Sales", k.totalSalesAmount, Icons.Default.TrendingUp, Emphasis.POSITIVE),
                Kpi("Total Expense", k.totalExpenseAmount, Icons.Default.TrendingDown, Emphasis.NEGATIVE),
                Kpi("Bricks Sold (Qty)", k.totalBricksSoldQty, Icons.Default.Inventory2),
                Kpi("Customer Due", k.totalCustomerDue, Icons.Default.PersonOutline, if (k.totalCustomerDue > 0) Emphasis.NEGATIVE else Emphasis.POSITIVE),
                Kpi("Partner Due", k.totalPartnerDue, Icons.Default.Groups, if (k.totalPartnerDue > 0) Emphasis.NEGATIVE else Emphasis.POSITIVE),
                Kpi("Payable Expense Due", k.totalPayableExpenseDue, Icons.Default.ReceiptLong, if (k.totalPayableExpenseDue > 0) Emphasis.NEGATIVE else Emphasis.POSITIVE),
                Kpi("Diesel Stock (L)", k.dieselStockLiter, Icons.Default.LocalGasStation),
                Kpi("Coal Stock", k.coalStock, Icons.Default.Whatshot),
                Kpi("Advance Sale", k.totalAdvanceSale, Icons.Default.Schedule),
                Kpi("Regular Sale", k.totalRegularSale, Icons.Default.ShoppingCart),
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.heightIn(max = 900.dp)
            ) {
                items(items) { kpi -> KpiCard(kpi) }
            }
        }
    }

    if (showDaily) {
        DailyReportDialog(vm, onDismiss = { showDaily = false })
    }
}

@Composable
private fun KpiCard(kpi: Kpi) {
    val valueColor = when (kpi.emphasis) {
        Emphasis.POSITIVE -> MaterialTheme.colorScheme.tertiary
        Emphasis.NEGATIVE -> MaterialTheme.colorScheme.error
        Emphasis.NEUTRAL -> MaterialTheme.colorScheme.onSurface
    }
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(kpi.icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            Spacer(Modifier.height(8.dp))
            Text(kpi.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text("৳${"%,.0f".format(kpi.value)}", style = MaterialTheme.typography.titleMedium, color = valueColor)
        }
    }
}

@Composable
private fun DailyReportDialog(vm: DashboardViewModel, onDismiss: () -> Unit) {
    val sales by vm.dailySales.collectAsState()
    val expenses by vm.dailyExpenses.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.Today, contentDescription = null) },
        title = { Text("আজকের Daily Report") },
        text = {
            Column {
                DailyReportRow(Icons.Default.ShoppingCart, "বিক্রয়", sales.size, sales.sumOf { it.amount })
                Spacer(Modifier.height(10.dp))
                DailyReportRow(Icons.Default.ReceiptLong, "খরচ", expenses.size, expenses.sumOf { it.amount })
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("বন্ধ করুন") } }
    )
}

@Composable
private fun DailyReportRow(icon: ImageVector, label: String, count: Int, total: Double) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text("$label — $count entries", style = MaterialTheme.typography.bodyMedium)
            Text("৳${"%,.2f".format(total)}", style = MaterialTheme.typography.titleSmall)
        }
    }
}
