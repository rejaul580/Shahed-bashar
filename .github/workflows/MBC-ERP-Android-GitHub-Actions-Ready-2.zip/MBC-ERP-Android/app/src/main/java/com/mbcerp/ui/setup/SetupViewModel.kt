package com.mbcerp.ui.setup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.*
import com.mbcerp.repository.SetupRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class SetupViewModel(private val repo: SetupRepository) : ViewModel() {

    val companyProfile: StateFlow<CompanyProfileEntity?> =
        repo.observeCompanyProfile().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val partners: StateFlow<List<PartnerEntity>> =
        repo.observePartners().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val majhis: StateFlow<List<MajhiEntity>> =
        repo.observeMajhis().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val brickTypes: StateFlow<List<BrickTypeEntity>> =
        repo.observeBrickTypes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val equipment: StateFlow<List<EquipmentEntity>> =
        repo.observeEquipment().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenseCategories: StateFlow<List<ExpenseCategoryEntity>> =
        repo.observeExpenseCategories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<CustomerEntity>> =
        repo.observeCustomers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Phase 1 item 5: Baseline Date configuration UI hook. */
    fun updateBaselineDate(date: LocalDate) {
        viewModelScope.launch { repo.updateBaselineDate(date) }
    }

    fun addPartner(name: String, capital: Double, shareAnna: Double, openingDue: Double, mobile: String?) {
        viewModelScope.launch { repo.addPartner(PartnerEntity(name = name, capital = capital, shareAnna = shareAnna, openingDue = openingDue, mobile = mobile)) }
    }

    fun updatePartner(partner: PartnerEntity) {
        viewModelScope.launch { repo.updatePartner(partner) }
    }

    fun addMajhi(name: String) {
        viewModelScope.launch { repo.addMajhi(MajhiEntity(name = name)) }
    }

    fun addBrickType(category: String, rate: Double, unitSize: Double?, unitDescription: String?) {
        viewModelScope.launch { repo.addBrickType(BrickTypeEntity(category = category, rate = rate, unitSize = unitSize, unitDescription = unitDescription)) }
    }

    fun addEquipment(name: String, type: String, hourlyRate: Double, driver: String?) {
        viewModelScope.launch { repo.addEquipment(EquipmentEntity(name = name, type = type, hourlyRate = hourlyRate, driverName = driver)) }
    }

    fun addExpenseCategory(category: String) {
        viewModelScope.launch { repo.addExpenseCategory(ExpenseCategoryEntity(category = category)) }
    }

    fun addCustomer(name: String, openingDue: Double, mobile: String?) {
        viewModelScope.launch { repo.addCustomer(CustomerEntity(name = name, openingDue = openingDue, mobile = mobile)) }
    }

    fun updateCustomer(customer: CustomerEntity) {
        viewModelScope.launch { repo.updateCustomer(customer) }
    }
}

class SetupViewModelFactory(private val repo: SetupRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = SetupViewModel(repo) as T
}
