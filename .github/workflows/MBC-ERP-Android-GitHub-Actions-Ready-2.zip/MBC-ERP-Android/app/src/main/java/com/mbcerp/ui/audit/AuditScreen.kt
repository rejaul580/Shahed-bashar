package com.mbcerp.ui.audit

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.domain.calc.ValidationEngine
import com.mbcerp.repository.AuditRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/** AUDIT / VALIDATION SCREEN (Phase 9, AUDIT §2.11 "Audit Sheet"). Self-diagnostic only -- creates no data. */
class AuditViewModel(private val auditRepository: AuditRepository) : ViewModel() {
    private val _results = MutableStateFlow<List<ValidationEngine.AuditResult>>(emptyList())
    val results: StateFlow<List<ValidationEngine.AuditResult>> = _results
    fun runChecks() = viewModelScope.launch { _results.value = auditRepository.runAllChecks() }
}

class AuditViewModelFactory(private val auditRepository: AuditRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AuditViewModel(auditRepository) as T
}

@Composable
fun AuditScreen(vm: AuditViewModel) {
    val results by vm.results.collectAsState()
    LaunchedEffect(Unit) { vm.runChecks() }

    Scaffold(topBar = { TopAppBar(title = { Text("Audit / Validation") }) }) { padding ->
        Column(Modifier.padding(padding).padding(12.dp)) {
            val failCount = results.count { !it.ok }
            Text(
                if (failCount == 0) "সব চেক পাশ ✓" else "$failCount টা চেক-এ সমস্যা পাওয়া গেছে",
                style = MaterialTheme.typography.titleMedium,
                color = if (failCount == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn {
                items(results) { r ->
                    ListItem(
                        leadingContent = {
                            Icon(
                                if (r.ok) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = null,
                                tint = if (r.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        },
                        headlineContent = { Text(r.check) },
                        supportingContent = r.detail?.let { { Text(it) } }
                    )
                    Divider()
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.runChecks() }) { Text("Re-run Checks") }
        }
    }
}
