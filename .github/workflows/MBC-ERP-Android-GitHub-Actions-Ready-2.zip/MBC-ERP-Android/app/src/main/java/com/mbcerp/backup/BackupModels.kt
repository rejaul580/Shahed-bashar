package com.mbcerp.backup

/**
 * GOOGLE DRIVE BACKUP/RESTORE (item 6).
 *
 * SCOPE: backs up every Room table (all ERP data, edits, and settings -- Setup master
 * data, Sales, Expenses, Ledgers' underlying rows, Cash Summary adjustments, Weather
 * Alert settings, everything) as ONE timestamped JSON file uploaded to the user's own
 * Google Drive (their normal Drive storage, in a visible "MBC ERP Backups" folder --
 * NOT the hidden appDataFolder, so the user can see/manage the files themselves).
 *
 * The original source Excel file is never touched by this app at all after the
 * one-time Phase-1 migration (it isn't even bundled in the APK, only its extracted
 * JSON data is) -- so "keeping the master Excel unchanged" is automatically satisfied;
 * there is no code path in this app that could write back to an .xlsx file.
 *
 * SETUP REQUIRED BEFORE THIS COMPILES/RUNS (cannot be completed from inside this
 * sandbox -- requires a real Google Cloud Console project, which needs a live Google
 * account and network access):
 *   1. Create a Google Cloud project, enable the "Google Drive API".
 *   2. Create an OAuth 2.0 Android client ID (needs the app's real release/debug
 *      signing certificate SHA-1, which does not exist until this project is actually
 *      built once by a developer).
 *   3. Add that client ID's config via the standard Google Sign-In setup (either
 *      google-services.json + the Google Services Gradle plugin, or manual
 *      GoogleSignInOptions.Builder(...).requestServerAuthCode(...) wiring).
 * None of this can be done by an AI code-writing pass alone -- it requires a human
 * with access to Google Cloud Console. The code below is written against the
 * documented Google Drive REST API v3 + Credentials API and is structurally complete,
 * but has NOT been run against a live Drive account (no network in this sandbox).
 */
data class BackupManifest(
    val schemaVersion: Int,
    val exportedAtMillis: Long,
    val appVersionName: String,
    val tableRowCounts: Map<String, Int>
)

data class BackupBundle(
    val manifest: BackupManifest,
    val tablesJson: Map<String, String> // table name -> JSON array of rows
)
