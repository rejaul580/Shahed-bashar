package com.mbcerp.ui.sales

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.ui.common.EmptyState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesListScreen(vm: SalesListViewModel, onAddClick: () -> Unit) {
    val filter by vm.filter.collectAsState()
    val rows by vm.visibleRows.collectAsState()
    val total by vm.totalAmount.collectAsState()
    var editingRow by remember { mutableStateOf<SaleRow?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("বিক্রয় তালিকা (${rows.size})") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddClick) { Icon(Icons.Default.Add, contentDescription = "Add Sale") } }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = filter.query,
                onValueChange = vm::updateQuery,
                label = { Text("খুঁজুন: Voucher / Party / Truck") },
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            )
            Row(Modifier.padding(horizontal = 8.dp)) {
                FilterChip(selected = filter.partyType == null, onClick = { vm.updatePartyType(null) }, label = { Text("সব") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = filter.partyType == "Customer", onClick = { vm.updatePartyType("Customer") }, label = { Text("Customer") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = filter.partyType == "Partner", onClick = { vm.updatePartyType("Partner") }, label = { Text("Partner") })
            }
            Text("মোট Amount (ফিল্টার করা তালিকা): ৳${"%,.2f".format(total)}", modifier = Modifier.padding(8.dp))
            Text("এন্ট্রি tap করলে edit করা যাবে", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 8.dp))
            Divider()
            if (rows.isEmpty()) {
                EmptyState(
                    icon = Icons.Default.ShoppingCart,
                    title = "কোনো বিক্রয় পাওয়া যায়নি",
                    subtitle = if (filter.query.isNotBlank() || filter.partyType != null) "ফিল্টার পরিবর্তন করে দেখুন" else "নিচের + বাটনে চাপ দিয়ে নতুন বিক্রয় এন্ট্রি দিন"
                )
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(rows, key = { it.sale.id }) { row ->
                    ListItem(
                        headlineContent = { Text("${row.sale.date}  •  ${row.sale.partyName} (${row.sale.partyType})") },
                        supportingContent = {
                            Text(
                                "Voucher: ${row.sale.voucherNo ?: "-"}  |  ${row.sale.brickCategory}  |  " +
                                "Qty: ${row.sale.quantity}  |  Amount: ৳${row.sale.amount}  |  Due: ৳${row.due}" +
                                (row.sale.saleType?.let { "  |  $it" } ?: "")
                            )
                        },
                        modifier = Modifier.clickable { editingRow = row }
                    )
                    Divider()
                }
            }
        }
    }

    editingRow?.let { row ->
        EditSaleDialog(
            sale = row.sale,
            onDismiss = { editingRow = null },
            onSave = { updated -> vm.updateSale(updated); editingRow = null },
            onDelete = { vm.deleteSale(row.sale.id); editingRow = null }
        )
    }
}

@Composable
private fun EditSaleDialog(sale: SaleEntity, onDismiss: () -> Unit, onSave: (SaleEntity) -> Unit, onDelete: () -> Unit) {
    var date by remember { mutableStateOf(sale.date) }
    var voucherNo by remember { mutableStateOf(sale.voucherNo ?: "") }
    var truckNo by remember { mutableStateOf(sale.truckNo ?: "") }
    var brickCategory by remember { mutableStateOf(sale.brickCategory) }
    var quantity by remember { mutableStateOf(sale.quantity.toString()) }
    var rate by remember { mutableStateOf(sale.rate.toString()) }
    var amount by remember { mutableStateOf(sale.amount.toString()) }
    var advance by remember { mutableStateOf(sale.advancePayment.toString()) }
    var cash by remember { mutableStateOf(sale.cashReceived.toString()) }
    var remarks by remember { mutableStateOf(sale.remarks ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("বিক্রয় এন্ট্রি Edit করুন") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("${sale.partyName} (${sale.partyType}) -- পার্টির নাম/টাইপ এখান থেকে বদলানো যাবে না, দরকার হলে delete করে নতুন এন্ট্রি দিন।", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(date, { date = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(voucherNo, { voucherNo = it }, label = { Text("Voucher No") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(truckNo, { truckNo = it }, label = { Text("Truck No") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(brickCategory, { brickCategory = it }, label = { Text("Brick Category") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(quantity, { quantity = it }, label = { Text("Quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(rate, { rate = it }, label = { Text("Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(advance, { advance = it }, label = { Text("Advance Payment") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cash, { cash = it }, label = { Text("Cash Received (+/-)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(remarks, { remarks = it }, label = { Text("Remarks") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                if (!confirmDelete) {
                    TextButton(onClick = { confirmDelete = true }) { Text("Delete This Entry", color = MaterialTheme.colorScheme.error) }
                } else {
                    Text("আসলেই delete করবেন? এই entry Sales Register থেকে সরে যাবে (soft-delete, audit trail থাকবে)।", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = onDelete) { Text("হ্যাঁ, Delete করুন", color = MaterialTheme.colorScheme.error) }
                        TextButton(onClick = { confirmDelete = false }) { Text("না") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    sale.copy(
                        date = date, voucherNo = voucherNo.ifBlank { null }, truckNo = truckNo.ifBlank { null },
                        brickCategory = brickCategory, quantity = quantity.toDoubleOrNull() ?: 0.0,
                        rate = rate.toDoubleOrNull() ?: 0.0, amount = amount.toDoubleOrNull() ?: 0.0,
                        advancePayment = advance.toDoubleOrNull() ?: 0.0, cashReceived = cash.toDoubleOrNull() ?: 0.0,
                        remarks = remarks.ifBlank { null }
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
