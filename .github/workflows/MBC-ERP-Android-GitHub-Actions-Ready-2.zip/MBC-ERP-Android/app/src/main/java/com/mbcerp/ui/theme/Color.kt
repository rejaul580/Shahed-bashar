package com.mbcerp.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Brand palette — grounded in the actual subject (a brickfield): fired-clay reds,
 * kiln char, ash cream. Not a generic default Material palette.
 */

// Light scheme
val BrickPrimary = Color(0xFF9A4A2E)       // fired brick red
val BrickOnPrimary = Color(0xFFFFFFFF)
val BrickPrimaryContainer = Color(0xFFFFDBCC)
val BrickOnPrimaryContainer = Color(0xFF3A0900)

val ClaySecondary = Color(0xFF77574A)       // raw clay
val ClayOnSecondary = Color(0xFFFFFFFF)
val ClaySecondaryContainer = Color(0xFFFFDBCC)
val ClayOnSecondaryContainer = Color(0xFF2C160C)

val EmberTertiary = Color(0xFF6C5D2F)       // kiln ember / amber
val EmberOnTertiary = Color(0xFFFFFFFF)
val EmberTertiaryContainer = Color(0xFFF5E1A7)
val EmberOnTertiaryContainer = Color(0xFF221B00)

val LightBackground = Color(0xFFFFF8F5)
val LightOnBackground = Color(0xFF261812)
val LightSurface = Color(0xFFFFF8F5)
val LightSurfaceVariant = Color(0xFFF5DED4)
val LightOnSurfaceVariant = Color(0xFF53433C)
val LightOutline = Color(0xFF85736A)

val ErrorRed = Color(0xFFBA1A1A)
val OnErrorRed = Color(0xFFFFFFFF)
val ErrorContainer = Color(0xFFFFDAD6)
val OnErrorContainer = Color(0xFF410002)

val SuccessGreen = Color(0xFF3B6939)        // used for "PASS"/positive due states
val SuccessContainer = Color(0xFFBCF0B4)

// Dark scheme (kiln-at-night)
val BrickPrimaryDark = Color(0xFFFFB59D)
val BrickOnPrimaryDark = Color(0xFF5F1600)
val BrickPrimaryContainerDark = Color(0xFF7C2E13)
val BrickOnPrimaryContainerDark = Color(0xFFFFDBCC)

val ClaySecondaryDark = Color(0xFFE7BFAF)
val ClayOnSecondaryDark = Color(0xFF442A1F)
val ClaySecondaryContainerDark = Color(0xFF5D4034)
val ClayOnSecondaryContainerDark = Color(0xFFFFDBCC)

val DarkBackground = Color(0xFF1C1512)
val DarkOnBackground = Color(0xFFEDE6DA)
val DarkSurface = Color(0xFF1C1512)
val DarkSurfaceVariant = Color(0xFF53433C)
val DarkOnSurfaceVariant = Color(0xFFD8C2B8)
val DarkOutline = Color(0xFFA08D83)
