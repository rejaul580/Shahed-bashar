package com.mbcerp.pdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.mbcerp.data.entity.SaleEntity
import java.io.File
import java.io.FileOutputStream

/**
 * REAL PDF OUTPUT (Phase-4 item 8) for Delivery Challan and Money Receipt, using
 * Android's built-in android.graphics.pdf.PdfDocument -- no external library needed,
 * works fully offline. Produces an actual A5-ish single-page PDF, saved to app-private
 * storage and exposed via FileProvider for sharing/printing through the system share
 * sheet or a print service.
 *
 * NOTE ON TESTING: this draws using the standard Android Canvas/Paint API, the same
 * mechanism used by every Android view -- the drawing calls themselves are ordinary,
 * well-documented platform APIs. However, actually opening the resulting PDF file and
 * visually confirming layout correctness requires a device/emulator, which this
 * sandbox does not have. The code has not been visually verified on-device.
 */
object PdfGenerator {

    private const val PAGE_WIDTH = 420  // ~A5 width in points at 72dpi-ish scale
    private const val PAGE_HEIGHT = 595

    fun generateDeliveryChallan(context: Context, sale: SaleEntity, companyName: String): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply { color = Color.BLACK; textSize = 18f; isFakeBoldText = true }
        val headerPaint = Paint().apply { color = Color.BLACK; textSize = 13f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { color = Color.DKGRAY; textSize = 11f }
        val linePaint = Paint().apply { color = Color.LTGRAY; strokeWidth = 1f }

        var y = 40f
        canvas.drawText(companyName, 20f, y, titlePaint)
        y += 22f
        canvas.drawText("DELIVERY CHALLAN", 20f, y, headerPaint)
        y += 10f
        canvas.drawLine(20f, y, PAGE_WIDTH - 20f, y, linePaint)
        y += 24f

        val fields = listOf(
            "Date" to sale.date,
            "Voucher No" to (sale.voucherNo ?: "-"),
            "Truck No" to (sale.truckNo ?: "-"),
            "Party" to "${sale.partyName} (${sale.partyType})",
            "Location" to (sale.location ?: "-"),
            "Brick Category" to sale.brickCategory,
            "Quantity" to sale.quantity.toString(),
            "Rate" to sale.rate.toString(),
            "Amount" to "৳${sale.amount}"
        )
        for ((label, value) in fields) {
            canvas.drawText("$label:", 20f, y, headerPaint)
            canvas.drawText(value, 160f, y, bodyPaint)
            y += 22f
        }

        y += 30f
        canvas.drawLine(20f, y, 160f, y, linePaint)
        canvas.drawText("Receiver's Signature", 20f, y + 14f, bodyPaint)
        canvas.drawLine(PAGE_WIDTH - 160f, y, PAGE_WIDTH - 20f, y, linePaint)
        canvas.drawText("Authorized Signature", PAGE_WIDTH - 160f, y + 14f, bodyPaint)

        document.finishPage(page)
        val file = File(context.cacheDir, "delivery_challan_${sale.voucherNo ?: sale.id}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    data class MoneyReceiptData(
        val receiptNo: String,
        val date: String,
        val receivedFrom: String,
        val mobile: String?,
        val amount: Double,
        val amountInWords: String,
        val receivedAgainst: String,
        val remarks: String?
    )

    fun generateMoneyReceipt(context: Context, data: MoneyReceiptData, companyName: String): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply { color = Color.BLACK; textSize = 18f; isFakeBoldText = true }
        val headerPaint = Paint().apply { color = Color.BLACK; textSize = 13f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { color = Color.DKGRAY; textSize = 11f }
        val linePaint = Paint().apply { color = Color.LTGRAY; strokeWidth = 1f }

        var y = 40f
        canvas.drawText(companyName, 20f, y, titlePaint)
        y += 22f
        canvas.drawText("MONEY RECEIPT", 20f, y, headerPaint)
        canvas.drawText("No: ${data.receiptNo}", PAGE_WIDTH - 140f, y, bodyPaint)
        y += 10f
        canvas.drawLine(20f, y, PAGE_WIDTH - 20f, y, linePaint)
        y += 24f

        val fields = listOf(
            "Date" to data.date,
            "Received From" to data.receivedFrom,
            "Mobile" to (data.mobile ?: "-"),
            "Amount" to "৳${data.amount}",
            "In Words" to data.amountInWords,
            "Received Against" to data.receivedAgainst,
            "Remarks" to (data.remarks ?: "-")
        )
        for ((label, value) in fields) {
            canvas.drawText("$label:", 20f, y, headerPaint)
            canvas.drawText(value, 160f, y, bodyPaint)
            y += 22f
        }

        y += 30f
        canvas.drawLine(PAGE_WIDTH - 160f, y, PAGE_WIDTH - 20f, y, linePaint)
        canvas.drawText("Authorized Signature", PAGE_WIDTH - 160f, y + 14f, bodyPaint)

        document.finishPage(page)
        val file = File(context.cacheDir, "money_receipt_${data.receiptNo}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    /** Returns a content:// Uri via FileProvider so the PDF can be shared/printed through the system share sheet. */
    fun shareUriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}
