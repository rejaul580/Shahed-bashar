package com.mbcerp.ui.production

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ProductionEntryEntity
import com.mbcerp.repository.ProductionRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * PRODUCTION REGISTER (Phase 8, AUDIT §2.9). Decision D6: stock estimate faithfully
 * replicates the source's "1 No"/"2 No" only coverage rather than expanding it --
 * see ProductionRepository.stockEstimate() / StockCalculator.productionStockEstimate().
 */
class ProductionViewModel(private val productionRepository: ProductionRepository) : ViewModel() {
    val entries = productionRepository.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _stockEstimate = MutableStateFlow(0.0)
    val stockEstimate: StateFlow<Double> = _stockEstimate

    fun loadStock() = viewModelScope.launch { _stockEstimate.value = productionRepository.stockEstimate() }
    fun addEntry(e: ProductionEntryEntity) = viewModelScope.launch { productionRepository.addEntry(e); loadStock() }
}

class ProductionViewModelFactory(private val productionRepository: ProductionRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ProductionViewModel(productionRepository) as T
}

@Composable
fun ProductionScreen(vm: ProductionViewModel) {
    val entries by vm.entries.collectAsState()
    val stock by vm.stockEstimate.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadStock() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Production Register") }) },
        floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Default.Add, contentDescription = "Add") } }
    ) { padding ->
        Column(Modifier.padding(padding).padding(12.dp)) {
            Text("Estimated Current Stock: ${"%,.0f".format(stock)} (শুধু 1 No / 2 No কভার করা, Decision D6)", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            LazyColumn {
                items(entries) { e ->
                    ListItem(
                        headlineContent = { Text("${e.date}  ${e.type ?: ""}") },
                        supportingContent = { Text("Loaded: ${e.loadedToKiln}  |  Fired Out: ${e.unloadedFiredOut}  |  Majhi: ${e.majhiName ?: "-"}") }
                    )
                    Divider()
                }
            }
        }
    }

    if (showDialog) {
        var date by remember { mutableStateOf(LocalDate.now().toString()) }
        var majhi by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Manual") }
        var raw by remember { mutableStateOf("0") }
        var loaded by remember { mutableStateOf("0") }
        var fired by remember { mutableStateOf("0") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন Production Entry") },
            text = {
                Column {
                    OutlinedTextField(date, { date = it }, label = { Text("Date") })
                    OutlinedTextField(majhi, { majhi = it }, label = { Text("Majhi") })
                    Row { FilterChip(selected = type == "Manual", onClick = { type = "Manual" }, label = { Text("Manual") }); Spacer(Modifier.width(8.dp)); FilterChip(selected = type == "Auto", onClick = { type = "Auto" }, label = { Text("Auto") }) }
                    OutlinedTextField(raw, { raw = it }, label = { Text("Raw Bricks Counted") })
                    OutlinedTextField(loaded, { loaded = it }, label = { Text("Loaded To Kiln") })
                    OutlinedTextField(fired, { fired = it }, label = { Text("Fired Out (Pucca)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addEntry(
                        ProductionEntryEntity(
                            date = date, majhiName = majhi.ifBlank { null }, type = type,
                            rawBricksCounted = raw.toDoubleOrNull() ?: 0.0,
                            loadedToKiln = loaded.toDoubleOrNull() ?: 0.0,
                            unloadedFiredOut = fired.toDoubleOrNull() ?: 0.0
                        )
                    )
                    showDialog = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }
}
