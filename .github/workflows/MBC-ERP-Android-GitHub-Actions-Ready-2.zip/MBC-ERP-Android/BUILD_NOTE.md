# Build Note (sandbox limitation)

This sandbox has no network access, so the Gradle wrapper JAR
(gradle/wrapper/gradle-wrapper.jar) and the Android Gradle Plugin /
Kotlin compiler / Compose compiler could not be downloaded, and a
real `./gradlew assembleDebug` could not be executed here.

`gradle/wrapper/gradle-wrapper.properties` is included (points at
Gradle 8.7) so that opening this project in Android Studio will let
Android Studio generate the wrapper jar and sync normally with an
internet connection.

Everything that COULD be verified without Gradle/Android Studio was
verified — see VALIDATION_REPORT.md (65/65 calculation-engine checks
passed against the real Excel data).
