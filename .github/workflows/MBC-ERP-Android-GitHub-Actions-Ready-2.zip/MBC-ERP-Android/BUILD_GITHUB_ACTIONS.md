# GitHub Actions Build Guide

This project is configured to build the debug APK on GitHub Actions without requiring a local computer or a Gradle wrapper JAR.

## What the workflow does
1. Installs JDK 17.
2. Installs Gradle 8.7 through `gradle/actions/setup-gradle`.
3. Runs JVM unit tests.
4. Runs `assembleDebug`.
5. Uploads `app-debug.apk` as the `MBC-ERP-debug-apk` artifact.

## How to use
Upload the contents of this project to a GitHub repository. Then open **Actions → Android APK Build → Run workflow**.

When the job succeeds, open the completed workflow run and download **MBC-ERP-debug-apk** from the Artifacts section.

## Important
The Google Drive backup code is now table-complete, but live Google sign-in/Drive upload still requires a real Google Cloud OAuth configuration and cannot be validated in this offline environment.
